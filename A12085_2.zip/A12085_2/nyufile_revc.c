#include "nyufile_header.h"

unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);

void format_Filename(char *filename, const unsigned char *dirName) {
    int nameLen = 8;
    while (nameLen > 0 && dirName[nameLen - 1] == ' ') nameLen--;
    strncpy(filename, (const char *)dirName, nameLen);
    filename[nameLen] = '\0';

    if (dirName[8] != ' ') {
        strcat(filename, ".");
        int extLen = 3;
        while (extLen > 0 && dirName[8 + extLen - 1] == ' ') extLen--;
        strncat(filename, (const char *)&dirName[8], extLen);
    }
}

void list_root_Directory(FILE *fp, BootEntry *boot) {
    unsigned long rootDirStart = (boot->BPB_RsvdSecCnt + (boot->BPB_NumFATs * boot->BPB_FATSz32)) * boot->BPB_BytsPerSec;
    fseek(fp, rootDirStart, SEEK_SET);
    DirEntry entry;
    char filename[13];
    int totalEntries = 0;

    while (fread(&entry, sizeof(DirEntry), 1, fp) == 1) {
        if (entry.DIR_Name[0] == 0x00) { // End of directory entries
            break;
        }
        if (entry.DIR_Name[0] == 0xE5 || entry.DIR_Attr & 0x0F) { // Skip deleted and LFN entries
            continue;
        }
        format_Filename(filename, entry.DIR_Name);
        printf("%s", filename);
        if (entry.DIR_Attr & 0x10) { // Directory
            printf("/ (starting cluster = %d)\n", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
        } else { // File
            printf(" (size = %d", entry.DIR_FileSize);
            if (entry.DIR_FileSize > 0) {
                printf(", starting cluster = %d", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
            }
            printf(")\n");
        }
        totalEntries++;
    }
    printf("Total number of entries = %d\n", totalEntries);
}

void recover_File(FILE *fp, BootEntry *boot, const char *filename) {
    unsigned long rootDirStart = (boot->BPB_RsvdSecCnt + (boot->BPB_NumFATs * boot->BPB_FATSz32)) * boot->BPB_BytsPerSec;
    fseek(fp, rootDirStart, SEEK_SET);
    DirEntry entry;
    char entryName[13];
    int found = 0;

    while (fread(&entry, sizeof(DirEntry), 1, fp) == 1) {
        if (entry.DIR_Name[0] == 0x00) break; // End of directory entries
        if (entry.DIR_Name[0] == 0xE5) { // Deleted files
            format_Filename(entryName, entry.DIR_Name + 1);
            if (strcasecmp(entryName, filename) == 0) {
                found = 1;
                entry.DIR_Name[0] = ' ';
                fseek(fp, -sizeof(DirEntry), SEEK_CUR);
                fwrite(&entry, sizeof(DirEntry), 1, fp);
                printf("%s: successfully recovered\n", filename);
                break;
            }
        }
    }

    if (!found) {
        printf("%s: file not found\n", filename);
    }
}

unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);
void recover_file(unsigned char *file_name, char flag, bool has_sha)
{
    // fat
    int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size);
    unsigned int root_dir_cluster = boot->BPB_RootClus; // cluster of the root directory, which can change

    DirEntry *del_dir = NULL;

    do
    {
        int count = 0;
        // current cluster of the root directory's address
        DirEntry *dir = (DirEntry *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size + (root_dir_cluster - 2) * cluster_size);
        while (dir->DIR_Name[0] != 0x00 && count * sizeof(DirEntry) < cluster_size)
        {
            if (dir->DIR_Name[0] != 0xE5) // not a deleted file, so skip
            {
                count++;
                dir++;
                continue;
            }

            // PARSE NAME
            unsigned char *name = (unsigned char *)malloc(13 * sizeof(char)); // 8 len + 3 end + 1 period + 1 \0
            int i = 0;
            while (dir->DIR_Name[i] != ' ' && i < 8)
            {
                name[i] = dir->DIR_Name[i];
                // memcpy(name[i], dir->DIR_Name[i], 1);
                i++;
            }
            if (dir->DIR_Name[8] == ' ')
                ;
            else
            {
                name[i] = '.';
                i++;
                if (dir->DIR_Name[8] != ' ')
                {
                    name[i] = dir->DIR_Name[8];
                    i++;
                }
                if (dir->DIR_Name[9] != ' ')
                {
                    name[i] = dir->DIR_Name[9];
                    i++;
                }
                if (dir->DIR_Name[10] != ' ')
                {
                    name[i] = dir->DIR_Name[10];
                    i++;
                }
            }
            name[i] = '\0';

            if (strncmp((char *)(file_name + 1), (char *)(name + 1), 11) != 0)
            {
                // not the same file
                count++;
                dir++;
                free(name);
                continue;
            }

            // recovery check sha1
            if (has_sha)
            {
                if (flag == 'R')
                {
                    unsigned int st_cluster = dir->DIR_FstClusHI << 16 | dir->DIR_FstClusLO;
                    unsigned int file_size = dir->DIR_FileSize;

                    unsigned int *fat = (unsigned int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size);

                    int del_clusters[19];
                    int count = 0;
                    for (int i = boot->BPB_RootClus; i <= 20; i++)
                    {
                        if (fat[i] == 0 && fat[i] != st_cluster)
                        {
                            del_clusters[count] = i;
                            count++;
                        }
                    }

                    int num_del_clusters = file_size / cluster_size;
                    if (file_size % cluster_size) num_del_clusters ++;
                    
                    int result[num_del_clusters];
                    result[0] = st_cluster;

                    if (recurse(del_clusters, result, 0, num_del_clusters, file_size) == 1)
                    {
                        // modify ƒirst character of filename to restore file
                        dir->DIR_Name[0] = file_name[0];

                        // for (int p = 0; p < num_del_clusters; p++) {
                        //     printf("%d*", result[p]);
                        // }
                        // printf("\n");

                        if (file_size == 0) // handle empty files
                        {
                            printf("%s: successfully recovered with SHA-1\n", file_name);
                            free(name);
                            return;
                        }

                        for (int cur_fat = 0; cur_fat < boot->BPB_NumFATs; cur_fat++)
                        {
                            int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + cur_fat * sector_size * boot->BPB_FATSz32);

                            int n;
                            for (n = 0; n < num_del_clusters - 1; n++)
                            {
                                fat[result[n]] = result[n + 1];
                            }
                            fat[result[n]] = 0x0FFFFFFF;
                        }

                        printf("%s: successfully recovered with SHA-1\n", file_name);

                        free(name);
                        return;
                    }
                }
                else
                {
                    unsigned int st_cluster = dir->DIR_FstClusHI << 16 | dir->DIR_FstClusLO;
                    unsigned int file_size = dir->DIR_FileSize;

                    unsigned char *cluster = (unsigned char *)disk +
                                             boot->BPB_RsvdSecCnt * sector_size +
                                             boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size +
                                             (st_cluster - 2) * cluster_size;

                    unsigned char file_sha1[SHA_DIGEST_LENGTH];
                    SHA1(cluster, file_size, file_sha1);

                    if (strncmp((char *)file_sha1, (char *)sha1, SHA_DIGEST_LENGTH) == 0)
                    {
                        // sha1 is the same!
                        del_dir = dir;
                        free(name);
                        break;
                    }
                }
            }
            else // no sha1 supplied
            {
                if (del_dir != NULL)
                {
                    printf("%s: multiple candidates found\n", file_name);
                    free(name);
                    return;
                }
                del_dir = dir;
            }
            free(name);
            count++;
            dir++;
        }
    } while ((root_dir_cluster = fat[root_dir_cluster]) < 0x0FFFFFF8);

    if (del_dir != NULL)
    {
        del_dir->DIR_Name[0] = file_name[0];

        unsigned int st_cluster = del_dir->DIR_FstClusHI << 16 | del_dir->DIR_FstClusLO;
        unsigned int file_size = del_dir->DIR_FileSize;                                  
        if (file_size == 0)
        {
            ;
        }
        else
        {
            int num_cluster_restored = 0;

            for (int cur_fat = 0; cur_fat < boot->BPB_NumFATs; cur_fat++)
            {
                int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + cur_fat * sector_size * boot->BPB_FATSz32);

                num_cluster_restored = 0;
                while ((num_cluster_restored + 1) * cluster_size < file_size)
                {
                    // current cluster points to next cluster
                    fat[st_cluster + num_cluster_restored] = st_cluster + num_cluster_restored + 1;
                    num_cluster_restored++;
                }
                fat[st_cluster + num_cluster_restored] = 0x0FFFFFFF; // ending
            }
        }

        if (has_sha)
            printf("%s: successfully recovered with SHA-1\n", file_name);
        else
            printf("%s: successfully recovered\n", file_name);
        return;
    }

    printf("%s: file not found\n", file_name);
}

void print_Fs_info(BootEntry *boot) {
    printf("Number of FATs = %d\n", boot->BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", boot->BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n", boot->BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", boot->BPB_RsvdSecCnt);
}

void print_Usage() {
    printf("Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a deleted file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
}

void format_filename(char *filename, const unsigned char *dirName) {
    int nameLen = 8;
    while (nameLen > 0 && dirName[nameLen - 1] == ' ') nameLen--;
    strncpy(filename, (const char *)dirName, nameLen);
    filename[nameLen] = '\0';

    if (dirName[8] != ' ') {
        strcat(filename, ".");
        int extLen = 3;
        while (extLen > 0 && dirName[8 + extLen - 1] == ' ') extLen--;
        strncat(filename, (const char *)&dirName[8], extLen);
    }
}

void list_root_directory(FILE *fp, BootEntry *boot) {
    unsigned long rootDirStart = (boot->BPB_RsvdSecCnt + (boot->BPB_NumFATs * boot->BPB_FATSz32)) * boot->BPB_BytsPerSec;
    fseek(fp, rootDirStart, SEEK_SET);
    DirEntry entry;
    char filename[13];
    int totalEntries = 0;

    while (fread(&entry, sizeof(DirEntry), 1, fp) == 1) {
        if (entry.DIR_Name[0] == 0x00) { // End of directory entries
            break;
        }
        if (entry.DIR_Name[0] == 0xE5 || entry.DIR_Attr & 0x0F) { // Skip deleted and LFN entries
            continue;
        }
        format_filename(filename, entry.DIR_Name);
        printf("%s", filename);
        if (entry.DIR_Attr & 0x10) { // Directory
            printf("/ (starting cluster = %d)\n", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
        } else { // File
            printf(" (size = %d", entry.DIR_FileSize);
            if (entry.DIR_FileSize > 0) {
                printf(", starting cluster = %d", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
            }
            printf(")\n");
        }
        totalEntries++;
    }
    printf("Total number of entries = %d\n", totalEntries);
}

