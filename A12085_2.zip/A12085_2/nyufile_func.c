#include "nyufile_header.h"

void print_usage() {
    printf("Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a contiguous file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
    exit(-1);
}

char int2ch(int para) {
    return (char)para;
}

void Milestone(int fd, char *recoveredFileName, int type) {
    if (type == 1) {
        print_information(fd);
    }
    if (type == 2) {
        printf_dir();
    }
}

void Milestone_complex(char *filename, char flag, int shaflag) {
    if (flag == 'r' || flag == 'R') {
        // void recover_file(unsigned char *file_name, char flag, bool has_sha);
        bool has_sha = false;
        if(shaflag) has_sha = true;
        recover_file(filename, flag, has_sha);
    }
}

void print_information(int fd) {
    BootEntry *map = (BootEntry *) mmap(NULL, 90, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);
    
    /*
        Number of FATs = 2
        Number of bytes per sector = 512
        Number of sectors per cluster = 1
        Number of reserved sectors = 32
    */
    printf("Number of FATs = %d\n", map->BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", map->BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n",  map->BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", map->BPB_RsvdSecCnt);

    munmap(map, 90);
}   

int recurse(int *possibilities, int *result, int cur, int size, unsigned int file_size)
{
    if (cur == size)
    {
        unsigned char test_file[cluster_size * 5]; 
        for (int i = 0; i < size; i++)
        {
            char *cluster = (char *)disk +
                            boot->BPB_RsvdSecCnt * sector_size +
                            boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size +
                            (result[i] - 2) * cluster_size;

            memcpy(test_file + i * cluster_size, cluster, cluster_size);
        }

        unsigned char file_sha1[SHA_DIGEST_LENGTH];
        SHA1(test_file, file_size, file_sha1);

        if (strncmp((char *)file_sha1, (char *)sha1, SHA_DIGEST_LENGTH) == 0)
        {
            return 1;
        }
        return 0;
    }
    for (int i = 0; i < size; i++)
    {
        int temp;

        if (possibilities[i] == -1)
            continue;

        temp = possibilities[i];
        result[cur] = temp;

        possibilities[i] = -1;

        if (recurse(possibilities, result, cur + 1, size, file_size) == 1)
            return 1;
        possibilities[i] = temp;
    }
    return 0;
}