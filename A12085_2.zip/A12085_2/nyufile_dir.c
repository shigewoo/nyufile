#include "nyufile_header.h"

void printf_dir()
{
    int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size);
    unsigned int root_dir_cluster = boot->BPB_RootClus;

    
    int total_count = 0;
    int deleted = 0;
    do
    {
        int count = 0;
        DirEntry *dir = (DirEntry *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size + (root_dir_cluster - 2) * cluster_size);
        while (dir->DIR_Name[0] != 0x00 && count * sizeof(DirEntry) < cluster_size)
        {
            if (dir->DIR_Name[0] == 0xE5) // deleted file
            {
                deleted++;
                count++;
                total_count++;
                dir++;
                continue;
            }

            // PARSE NAME
            unsigned char *name = (unsigned char *)malloc(13 * sizeof(char)); // 8 len + 3 end + 1 period + 1 \0
            int i = 0;
            while (dir->DIR_Name[i] != ' ' && i < 8)
            {
                name[i] = dir->DIR_Name[i];
                // memcpy(name[i], dir->DIR_Name[i], 1);
                i++;
            }

            unsigned int size = dir->DIR_FileSize;
            unsigned int st_cluster = dir->DIR_FstClusHI << 16 | dir->DIR_FstClusLO;

            if (dir->DIR_Attr == 0x10) // if is folder
                printf("%s/ (starting cluster = %d)\n", name, st_cluster);
            else
            { // regular file
                if (dir->DIR_Name[8] == ' ')
                    ;
                else
                {
                    name[i] = '.';
                    i++;
                    if (dir->DIR_Name[8] != ' ')
                    {
                        name[i] = dir->DIR_Name[8];
                        i++;
                    }
                    if (dir->DIR_Name[9] != ' ')
                    {
                        name[i] = dir->DIR_Name[9];
                        i++;
                    }
                    if (dir->DIR_Name[10] != ' ')
                    {
                        name[i] = dir->DIR_Name[10];
                        i++;
                    }
                }
                name[i] = '\0';
                if (size == 0) // if is empty file
                    printf("%s (size = %d)\n", name, size);
                else
                    printf("%s (size = %d, starting cluster = %d)\n", name, size, st_cluster);
            }
            count++;
            total_count++;
            dir++;
            free(name);
        }
    } while ((root_dir_cluster = fat[root_dir_cluster]) < 0x0FFFFFF8);
    printf("Total number of entries = %d\n", total_count - deleted);
}