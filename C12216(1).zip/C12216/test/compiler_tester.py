import os
import subprocess

pwd = os.getcwd()

# Linux 路径
target_dir = os.path.join(pwd, '../cmake-build-debug')
test_dir = os.path.join(pwd, "20241")

compile_path = os.path.join(target_dir, 'Compiler')  # Linux 下无 .exe
mips_path = os.path.join(target_dir, 'mips.txt')

testfile_dst = os.path.join(target_dir, "testfile.txt")
input_dst = os.path.join(target_dir, "input.txt")
output_dst = os.path.join(target_dir, "output.txt")

# 检测 cmake-build-debug 下是否有 Mars
mars_path = os.path.join(target_dir, 'Mars4Compiler.jar')
if not os.path.exists(mars_path):
    print('Cannot find Mars: copy one')
    os.system(f'cp Mars4Compiler.jar {target_dir}/')

print("data-set:", os.path.split(test_dir)[1])
for root, dirs, files in os.walk(test_dir):
    if len(dirs) != 0:  # 去除根目录
        continue

    rank = os.path.split(root)[1]
    print('[test rank ' + rank + ']')
    num = int(len(files) / 3)

    for i in range(1, num + 1):
        print('testfile', i, ': ', end='')

        # 拷贝测试文件
        testfile_src = os.path.join(root, f'testfile{i}.txt')
        input_src = os.path.join(root, f'input{i}.txt')
        output_src = os.path.join(root, f'output{i}.txt')
        os.system(f'cp -f "{testfile_src}" "{testfile_dst}"')
        os.system(f'cp -f "{input_src}" "{input_dst}"')
        os.system(f'cp -f "{output_src}" "{output_dst}"')

        # 运行编译器
        subprocess.run(compile_path, cwd=target_dir, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # 运行 Mars
        with open(input_dst, mode='r') as fin:
            sp = subprocess.Popen(["java", "-jar", "Mars4Compiler.jar", "mips.txt"],
                                  cwd=target_dir, stdin=fin, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            res_list = bytes.decode(sp.communicate()[0]).replace('\r\n', '\n').split('\n')[2:]
            sp.kill()

        # 对比结果
        with open(output_dst, mode='r') as fcheck:
            ans_list = fcheck.read().replace('\r\n', '\n').split('\n')

        line_num = min(len(ans_list), len(res_list))
        if abs(len(ans_list) - len(res_list)) > 1:
            print('[warning] line num diff too much! ans-res :', f"{len(ans_list)}-{len(res_list)}", end=' ')
        wrong_line = []
        flag = True
        for lno in range(line_num):
            if res_list[lno] != ans_list[lno]:
                wrong_line.append(lno + 1)
                flag = False
        print('pass' if flag else 'wrong at line ' + str(wrong_line))
