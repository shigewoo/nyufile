//
//

#ifndef COMPILER_SETTINGS_H
#define COMPILER_SETTINGS_H

#define LEXER_PRINT     false
#define PARSER_PRINT    false
#define ERROR_PRINT     false
#define IRCODE_PRINT    true
#define MIPS_PRINT      true

#endif //COMPILER_SETTINGS_H
