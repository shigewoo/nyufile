#include "nyufile_header.h"

unsigned char SHA1_NULL[] = { 0xda, 0x39, 0xa3, 0xee, 0x5e, 0x6b, 0x4b, 0x0d, 0x32, 0x55, \
                                    0xbf, 0xef, 0x95, 0x60, 0x18, 0x90, 0xaf, 0xd8, 0x07, 0x09 };

void recover_a_small_file(int fd, char *recoveredFileName, char *sha_algorithm) {
      
    unsigned char providedHash[SHA_DIGEST_LENGTH]={0};

    unsigned int matchingFileBoolean = 0;
    struct stat disk_stat;
    if (fstat(fd,&disk_stat)== -1) {
        fprintf(stderr,"FSTAT ON DISK FAILED\n");
        exit(1);   
    }

    unsigned char *disk = mmap(NULL, disk_stat.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);
    BootEntry *map = (BootEntry *) disk;
    int potentialAnswerEntry;
    
    unsigned int startingByte = map->BPB_BytsPerSec *  map->BPB_RsvdSecCnt + map->BPB_NumFATs * map->BPB_FATSz32 * \
    map->BPB_BytsPerSec + ((map->BPB_RootClus - 2) 
    * map->BPB_BytsPerSec * map->BPB_SecPerClus);

    unsigned char *FATBegin = disk + map->BPB_BytsPerSec * map->BPB_RsvdSecCnt;
    unsigned int *FAT = (unsigned int *) FATBegin, currCluster = map->BPB_RootClus;
    
    while (currCluster < 0x0FFFFFF8) {
        unsigned char *directoryPage = disk + startingByte + (currCluster - 2) * map->BPB_BytsPerSec * map->BPB_SecPerClus;
        for (int i = 0; i < map->BPB_SecPerClus* map->BPB_BytsPerSec; i += 32) {
                if (directoryPage[i] != 0xe5) continue;
                char formattedDirectoryName[12] = {0};
                int fff = formatFileName(&directoryPage[i], formattedDirectoryName);
                if (strcmp(formattedDirectoryName + 1, recoveredFileName + 1) == 0) {
                    potentialAnswerEntry = i + startingByte;
                    int boolin = areHashesEqual(disk, (DirEntry *) (char*)(disk + startingByte + i), providedHash);
                    if (boolin && sha_algorithm) {
                        matchingFileBoolean = 1;
                        break;
                    }
                    matchingFileBoolean++;
                }            
            }
        currCluster = FAT[currCluster];
    }

    if (matchingFileBoolean > 1) fprintf(stderr, "FAILURE: %s : multiple candidates found\n", recoveredFileName);
    else if (matchingFileBoolean == 1) 
    {

        unsigned char *entry = disk+potentialAnswerEntry;
        entry[0] = recoveredFileName[0];
        printf("%s successfully recovered\n", recoveredFileName);

    }
    else printf("%s : file not found\n", recoveredFileName);

    munmap(FAT,map->BPB_FATSz32 * map->BPB_BytsPerSec);
    munmap(map, disk_stat.st_size);
}

static unsigned char char2Hex(char num)
{
    if ((unsigned char) num >= '0' && (unsigned char) num <= '9' )
        return (unsigned char) num - '0';
    
    else if ((unsigned char) num >= 'A' && (unsigned char) num <= 'F')
        return (unsigned char) num - 'A' + 10;
    
    else if ((unsigned char) num >= 'a' && (unsigned char) num <= 'f')
        return (unsigned char) num - 'a' + 10;
    else 
       return 0xFF;

}

unsigned char *sha2RealHex(char *string, unsigned char *buffer)
{
    for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
    {
        unsigned char high4bits = char2Hex(string[i*2]);

        unsigned char low4bits = char2Hex(string[i*2+1]);

        if ((high4bits == 0xFF )||(low4bits == 0xFF))
            return NULL;
        buffer[i] = low4bits | (high4bits << 4);
    }
    return buffer;
}

int areHashesEqual(unsigned char *disk, DirEntry *directory, unsigned char hash[])
{
    BootEntry *map = (BootEntry *) disk;
    unsigned int currCluster = directory->DIR_FstClusLO | directory->DIR_FstClusHI << 16;

    unsigned int startingByte = map->BPB_BytsPerSec *  map->BPB_RsvdSecCnt + map->BPB_NumFATs * map->BPB_FATSz32 * \
    map->BPB_BytsPerSec + ((currCluster - 2) * map->BPB_BytsPerSec * map->BPB_SecPerClus);
     

    unsigned char *FATBegin = disk + map->BPB_BytsPerSec * map->BPB_RsvdSecCnt;
    unsigned int *FAT = (unsigned int *) FATBegin;

    unsigned int fileSize = directory->DIR_FileSize;
    if (fileSize == 0)
    {
        for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
        {
            if (hash[i]!=SHA1_NULL[i])
                return -1;
        }
        printf("Hash match found\n");
        return 1;
    }

    unsigned int bufferCount = 0;
    unsigned char *buffer = (unsigned char *) malloc(fileSize);

    if (buffer==NULL) {fprintf(stderr,"Memory Allocation Failed.\n");
        exit(1);
    }

    while (currCluster < 0x0FFFFFF8)
    {
    
    
        for (int i = 0; i < map->BPB_BytsPerSec * map->BPB_SecPerClus; i++)
        {
            buffer[bufferCount]= disk[i+startingByte];
            bufferCount++;

            if (bufferCount == fileSize) break;
        }

        currCluster = FAT[currCluster];
        startingByte = map->BPB_BytsPerSec *  map->BPB_RsvdSecCnt + map->BPB_NumFATs * map->BPB_FATSz32 * \
        map->BPB_BytsPerSec + ((currCluster - 2) * map->BPB_BytsPerSec * map->BPB_SecPerClus);
    }


    unsigned char temphash[SHA_DIGEST_LENGTH];
    SHA1(buffer,fileSize,temphash);
    free(buffer);
    

    int cnt = 0;
    for(int i = 0; i < SHA_DIGEST_LENGTH; i++){
        if (temphash[i]!=hash[i]) {
            cnt ++;
        }
    }
    if(cnt <= 3) {
        printf("Hash match found\n");
        return 1;
    }
    else {
        return -1;
    }
}
