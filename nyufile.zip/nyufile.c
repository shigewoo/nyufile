#include <sys/fcntl.h>
#include "nyufile_header.h"
char *filePath;
char *sha1Hash;

int main(int argc, int **argv) {
    
    extern char *optarg;
    extern int optind; //This variable is set by getopt to the index of the next element of the argv array to be processed. 
    extern int opterr;
    opterr = 0; //setting the err value to 0 because i do not want the getopt automated err message
    optind = 2; //i want to skip the diskname in the getopt process

    int fd = open( (char *) argv[1], O_RDWR);
    if (fd < 0) {
        fprintf(stderr,"This is not a valid disk.\n");
        exit(1);
    }

    if (argc < 3) {
        print_usage();
    }
    int opt = 0, option = 0;
    while ((opt = getopt(argc, (char * const*) argv, "ilr:R:s:")) != -1) {
        // void Milestone(int fd, char *recoveredFileName, int type)
        if (int2ch(opt) == 'i') {
            option += 1;
        }
        else if (int2ch(opt) == 'l') {
            option += 10;
            
        }
        else if (int2ch(opt) == 'r') {
            option += 100;
            filePath = optarg;
        }  
        else if (int2ch(opt) == 'R') {
            option += 1000;
            filePath = optarg;
        }
        else if (int2ch(opt) == 's') {
            option += 10000;
            sha1Hash = optarg;
        }
        else {
            print_usage();
        }
    }
    if (option == 1) {
        Milestone(fd, NULL, 1);
    }
    else if (option == 10) {
        Milestone(fd, NULL, 2);
    }
    else if (option == 100) {
        Milestone(fd, filePath, 3);
    }
    else if (option == 10100) {
        Milestone(fd, filePath, 4);
    }
    close(fd);
    return 0;
}