#include "nyufile_header.h"

void print_usage() {
    printf("Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a deleted file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
    exit(-1);
}

char int2ch(int para) {
    return (char)para;
}

void Milestone(int fd, char *recoveredFileName, int type) {
    if (type == 1) {
        print_information(fd);
    }
    if (type == 2) {
        print_directory(fd);
    }  
    if (type == 3) {
        recover_a_small_file(fd, recoveredFileName, NULL);
    }
    if (type == 4) {
        puts(sha1Hash);
        recover_a_small_file(fd, recoveredFileName, sha1Hash);
    }
}

void print_information(int fd) {
    BootEntry *map = (BootEntry *) mmap(NULL, 90, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);
    
    /*
        Number of FATs = 2
        Number of bytes per sector = 512
        Number of sectors per cluster = 1
        Number of reserved sectors = 32
    */
    printf("Number of FATs = %d\n", map->BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", map->BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n",  map->BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", map->BPB_RsvdSecCnt);

    munmap(map, 90);
}   

int formatFileName(char *directoryEntry, char *formatted_string)
{
    char isDirectory = directoryEntry[11] & 0x10;
    short position=0;
    for (int i = 0; i < 11; i++)
    {
        if (isDirectory && i == 8) break;

        if (!isDirectory && i ==8) {formatted_string[position] = '.'; position++;}

        if (directoryEntry[i] != ' ')
        {formatted_string[position] = directoryEntry[i]; position++;}
        else continue;
    }
    if (isDirectory) {
        formatted_string[position] = '/';
        return 1;
    }
    return 0;
}

void printDirectoryEntry(DirEntry *entry)
{
    unsigned int clusterNumber = entry->DIR_FstClusLO | entry->DIR_FstClusHI << 16;
    unsigned int fileSize = entry->DIR_FileSize;
    char formatted_string[12]={0};
    char isDirectory = formatFileName( (char *) entry, formatted_string);
    if (isDirectory) {
        printf("%.11s (starting cluster = %u)\n", formatted_string, clusterNumber);
    }
    else {
        printf("%.11s (size = %u, starting cluster = %u)\n", formatted_string, clusterNumber, fileSize); 
    }
    return;
}

void print_directory(int fd) {
    BootEntry *map = (BootEntry *) mmap(NULL, 90, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);

    unsigned int startingByte = map->BPB_BytsPerSec *  map->BPB_RsvdSecCnt + map->BPB_NumFATs * map->BPB_FATSz32 * \
    map->BPB_BytsPerSec + ((map->BPB_RootClus - 2) 
    * map->BPB_BytsPerSec * map->BPB_SecPerClus);

    unsigned int *FAT =  (unsigned int *) mmap(NULL, map->BPB_FATSz32 * map->BPB_BytsPerSec, PROT_READ, MAP_PRIVATE, fd, \
    map->BPB_BytsPerSec *  map->BPB_RsvdSecCnt);

    unsigned int currCluster = map->BPB_RootClus;
    int numberOfEntries = 0;

    while (currCluster < 0x0FFFFFF8) // >= 0x0FFFFFF8 is End of Cluster mark
    {       
        unsigned char *directoryPage = mmap(NULL, map->BPB_FATSz32 * map->BPB_BytsPerSec \
        , PROT_READ, MAP_PRIVATE, fd, startingByte + (currCluster - 2) * map->BPB_BytsPerSec * map->BPB_SecPerClus);
        
        for (int i = 0; i < map->BPB_BytsPerSec * map->BPB_SecPerClus; i += 32) {
            if (directoryPage[i] == 0xE5 || directoryPage[i+11] & 0x0F == 0x0F) continue;
            if (directoryPage[i] == 0x00) break;
            printDirectoryEntry( (DirEntry *) &directoryPage[i]);
            numberOfEntries++;
        }
        printf("Total number of entries: %d\n", numberOfEntries);
        munmap(directoryPage, map->BPB_FATSz32 * map->BPB_BytsPerSec);
        currCluster = FAT[currCluster];
    }

    munmap(FAT, map->BPB_FATSz32 * map->BPB_BytsPerSec);
    munmap(map, 90);
}

