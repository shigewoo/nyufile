#include "nyufile_header.h"

void print_usage() {
    printf("Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a contiguous file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
    exit(-1);
}

char int2ch(int para) {
    return (char)para;
}

void Milestone(int fd, char *recoveredFileName, int type) {
    if (type == 1) {
        print_information(fd);
    }
    if (type == 2) {
        printf_dir();
    }
}

void Milestone_complex(char *filename, char flag, int shaflag) {
    if (flag == 'r') {
        // void recover_file(unsigned char *file_name, char flag, bool has_sha);
        bool has_sha = false;
        if(shaflag) has_sha = true;
        recover_file(filename, flag, has_sha);
    }
}

void print_information(int fd) {
    BootEntry *map = (BootEntry *) mmap(NULL, 90, PROT_READ | PROT_WRITE, MAP_SHARED, fd,0);
    
    /*
        Number of FATs = 2
        Number of bytes per sector = 512
        Number of sectors per cluster = 1
        Number of reserved sectors = 32
    */
    printf("Number of FATs = %d\n", map->BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", map->BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n",  map->BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", map->BPB_RsvdSecCnt);

    munmap(map, 90);
}   
