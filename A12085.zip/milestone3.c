#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <stdbool.h>

#include <sys/mman.h>
#include <fcntl.h>
#include <sys/stat.h>

// Boot sector
#pragma pack(push,1)
typedef struct BootEntry {
  unsigned char  BS_jmpBoot[3];     // Assembly instruction to jump to boot code
  unsigned char  BS_OEMName[8];     // OEM Name in ASCII
  unsigned short BPB_BytsPerSec;    // Bytes per sector. Allowed values include 512, 1024, 2048, and 4096
  unsigned char  BPB_SecPerClus;    // Sectors per cluster (data unit). Allowed values are powers of 2, but the cluster size must be 32KB or smaller
  unsigned short BPB_RsvdSecCnt;    // Size in sectors of the reserved area
  unsigned char  BPB_NumFATs;       // Number of FATs
  unsigned short BPB_RootEntCnt;    // Maximum number of files in the root directory for FAT12 and FAT16. This is 0 for FAT32
  unsigned short BPB_TotSec16;      // 16-bit value of number of sectors in file system
  unsigned char  BPB_Media;         // Media type
  unsigned short BPB_FATSz16;       // 16-bit size in sectors of each FAT for FAT12 and FAT16. For FAT32, this field is 0
  unsigned short BPB_SecPerTrk;     // Sectors per track of storage device
  unsigned short BPB_NumHeads;      // Number of heads in storage device
  unsigned int   BPB_HiddSec;       // Number of sectors before the start of partition
  unsigned int   BPB_TotSec32;      // 32-bit value of number of sectors in file system. Either this value or the 16-bit value above must be 0
  unsigned int   BPB_FATSz32;       // 32-bit size in sectors of one FAT
  unsigned short BPB_ExtFlags;      // A flag for FAT
  unsigned short BPB_FSVer;         // The major and minor version number
  unsigned int   BPB_RootClus;      // Cluster where the root directory can be found
  unsigned short BPB_FSInfo;        // Sector where FSINFO structure can be found
  unsigned short BPB_BkBootSec;     // Sector where backup copy of boot sector is located
  unsigned char  BPB_Reserved[12];  // Reserved
  unsigned char  BS_DrvNum;         // BIOS INT13h drive number
  unsigned char  BS_Reserved1;      // Not used
  unsigned char  BS_BootSig;        // Extended boot signature to identify if the next three values are valid
  unsigned int   BS_VolID;          // Volume serial number
  unsigned char  BS_VolLab[11];     // Volume label in ASCII. User defines when creating the file system
  unsigned char  BS_FilSysType[8];  // File system type label in ASCII
} BootEntry;
#pragma pack(pop)

// Directory entry
#pragma pack(push,1)
typedef struct DirEntry {
  unsigned char  DIR_Name[11];      // File name
  unsigned char  DIR_Attr;          // File attributes
  unsigned char  DIR_NTRes;         // Reserved
  unsigned char  DIR_CrtTimeTenth;  // Created time (tenths of second)
  unsigned short DIR_CrtTime;       // Created time (hours, minutes, seconds)
  unsigned short DIR_CrtDate;       // Created day
  unsigned short DIR_LstAccDate;    // Accessed day
  unsigned short DIR_FstClusHI;     // High 2 bytes of the first cluster address
  unsigned short DIR_WrtTime;       // Written time (hours, minutes, seconds
  unsigned short DIR_WrtDate;       // Written day
  unsigned short DIR_FstClusLO;     // Low 2 bytes of the first cluster address
  unsigned int   DIR_FileSize;      // File size in bytes. (0 for directories)
} DirEntry;
#pragma pack(pop)



void print_fs_info(BootEntry *boot) {
    printf("Number of FATs = %d\n", boot->BPB_NumFATs);
    printf("Number of bytes per sector = %d\n", boot->BPB_BytsPerSec);
    printf("Number of sectors per cluster = %d\n", boot->BPB_SecPerClus);
    printf("Number of reserved sectors = %d\n", boot->BPB_RsvdSecCnt);
}

void print_usage() {
    printf("Usage: ./nyufile disk <options>\n");
    printf("  -i                     Print the file system information.\n");
    printf("  -l                     List the root directory.\n");
    printf("  -r filename [-s sha1]  Recover a deleted file.\n");
    printf("  -R filename -s sha1    Recover a possibly non-contiguous file.\n");
}

void format_filename(char *filename, const unsigned char *dirName) {
    int nameLen = 8;
    while (nameLen > 0 && dirName[nameLen - 1] == ' ') nameLen--;
    strncpy(filename, (const char *)dirName, nameLen);
    filename[nameLen] = '\0';

    if (dirName[8] != ' ') {
        strcat(filename, ".");
        int extLen = 3;
        while (extLen > 0 && dirName[8 + extLen - 1] == ' ') extLen--;
        strncat(filename, (const char *)&dirName[8], extLen);
    }
}

void list_root_directory(FILE *fp, BootEntry *boot) {
    unsigned long rootDirStart = (boot->BPB_RsvdSecCnt + (boot->BPB_NumFATs * boot->BPB_FATSz32)) * boot->BPB_BytsPerSec;
    fseek(fp, rootDirStart, SEEK_SET);
    DirEntry entry;
    char filename[13];
    int totalEntries = 0;

    while (fread(&entry, sizeof(DirEntry), 1, fp) == 1) {
        if (entry.DIR_Name[0] == 0x00) { // End of directory entries
            break;
        }
        if (entry.DIR_Name[0] == 0xE5 || entry.DIR_Attr & 0x0F) { // Skip deleted and LFN entries
            continue;
        }
        format_filename(filename, entry.DIR_Name);
        printf("%s", filename);
        if (entry.DIR_Attr & 0x10) { // Directory
            printf("/ (starting cluster = %d)\n", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
        } else { // File
            printf(" (size = %d", entry.DIR_FileSize);
            if (entry.DIR_FileSize > 0) {
                printf(", starting cluster = %d", entry.DIR_FstClusLO | (entry.DIR_FstClusHI << 16));
            }
            printf(")\n");
        }
        totalEntries++;
    }
    printf("Total number of entries = %d\n", totalEntries);
}

void recover_file(FILE *fp, BootEntry *boot, const char *filename) {
    unsigned long rootDirStart = (boot->BPB_RsvdSecCnt + (boot->BPB_NumFATs * boot->BPB_FATSz32)) * boot->BPB_BytsPerSec;
    fseek(fp, rootDirStart, SEEK_SET);
    DirEntry entry;
    char entryName[13];
    int found = 0;

    while (fread(&entry, sizeof(DirEntry), 1, fp) == 1) {
        if (entry.DIR_Name[0] == 0x00) break; // End of directory entries
        if (entry.DIR_Name[0] == 0xE5) { // Deleted files
            format_filename(entryName, entry.DIR_Name + 1);
            if (strcasecmp(entryName, filename) == 0) {
                found = 1;
                entry.DIR_Name[0] = ' ';
                fseek(fp, -sizeof(DirEntry), SEEK_CUR);
                fwrite(&entry, sizeof(DirEntry), 1, fp);
                printf("%s: successfully recovered\n", filename);
                break;
            }
        }
    }

    if (!found) {
        printf("%s: file not found\n", filename);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        print_usage();
        return 1;
    }

    char *disk_image = argv[1];
    FILE *fp = fopen(disk_image, "rb+");
    if (!fp) {
        fprintf(stderr, "Error opening disk image '%s'.\n", disk_image);
        return 1;
    }

    BootEntry boot;
    if (fread(&boot, sizeof(BootEntry), 1, fp) != 1) {
        fprintf(stderr, "Error reading boot sector from disk image.\n");
        fclose(fp);
        return 1;
    }

    if (strcmp(argv[2], "-i") == 0) {
        print_fs_info(&boot);
    } else if (strcmp(argv[2], "-l") == 0) {
        list_root_directory(fp, &boot);
    } else if (strcmp(argv[2], "-r") == 0 && argc == 4) {
        recover_file(fp, &boot, argv[3]);
    } else {
        printf("Invalid option or not implemented.\n");
        print_usage();
    }

    fclose(fp);
    return 0;
}
