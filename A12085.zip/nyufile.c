#include <sys/fcntl.h>
#include "nyufile_header.h"

void *disk;
BootEntry *boot;
unsigned int sector_size;
unsigned int cluster_size;
char sha1[SHA_DIGEST_LENGTH];
unsigned char *filename;

int main(int argc, int **argv) {
    
    extern char *optarg;
    extern int optind; //This variable is set by getopt to the index of the next element of the argv array to be processed. 
    extern int opterr;
    opterr = 0; //setting the err value to 0 because i do not want the getopt automated err message
    optind = 2; //i want to skip the diskname in the getopt process

    int fd = open( (char *) argv[1], O_RDWR, 0777);
    if (fd == -1) {
        fprintf(stderr, "error opening file");
        exit(-1);
    }
    if (argc < 3) {
        print_usage();
    }
    int opt = 0, option = 0;
    char flag; int shaflag = 0;
    while ((opt = getopt(argc, (char * const*) argv, "ilr:R:s:")) != -1) {
        // void Milestone(int fd, char *recoveredFileName, int type)
        if (int2ch(opt) == 'i') {
            option += 1;
        }
        else if (int2ch(opt) == 'l') {
            option += 10;   
        }
        else if (int2ch(opt) == 'r') {
            flag = 'r';
            shaflag = 0;
            filename = (unsigned char *)optarg;
        }  
        else if (int2ch(opt) == 'R') {
            flag = 'R';
            shaflag = 0;
            filename = (unsigned char *)optarg;
        }
        else if (int2ch(opt) == 's') {
            shaflag = 1;
            for (int j = 0; j < SHA_DIGEST_LENGTH * 2; j += 2) {
                sscanf(optarg + j, "%2x", (unsigned int *)(sha1 + j / 2));
            }
        }
        else {
            print_usage();
        }
    }


    if (flag == 'R' && !shaflag) {
        print_usage();
        exit(1);
    }
    // get file stat->size
    struct stat sb; // struct that stores info on file
    if (fstat(fd, &sb) == -1)
        fprintf(stderr, "error with file stat");

    disk = mmap(NULL, sb.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (disk == MAP_FAILED)
        fprintf(stderr, "error with mmap");

    boot = (BootEntry *)disk;
    sector_size = boot->BPB_BytsPerSec;
    cluster_size = sector_size * boot->BPB_SecPerClus;
    
    if (option == 1) {
        Milestone(fd, NULL, 1);
    }
    else if (option == 10) {
        Milestone(fd, NULL, 2);
    }
    else if (flag == 'r' || flag == 'R') {
        Milestone_complex(filename, flag, shaflag);
    }
    munmap(disk, sb.st_size);
    close(fd);
    return 0;
}