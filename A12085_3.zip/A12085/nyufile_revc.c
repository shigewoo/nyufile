#include "nyufile_header.h"

unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);
void recover_file(unsigned char *file_name, char flag, bool has_sha)
{
    // fat
    int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size);
    unsigned int root_dir_cluster = boot->BPB_RootClus; // cluster of the root directory, which can change

    DirEntry *del_dir = NULL;

    do
    {
        int count = 0;
        // current cluster of the root directory's address
        DirEntry *dir = (DirEntry *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size + (root_dir_cluster - 2) * cluster_size);
        while (dir->DIR_Name[0] != 0x00 && count * sizeof(DirEntry) < cluster_size)
        {
            if (dir->DIR_Name[0] != 0xE5) // not a deleted file, so skip
            {
                count++;
                dir++;
                continue;
            }

            // PARSE NAME
            unsigned char *name = (unsigned char *)malloc(13 * sizeof(char)); // 8 len + 3 end + 1 period + 1 \0
            int i = 0;
            while (dir->DIR_Name[i] != ' ' && i < 8)
            {
                name[i] = dir->DIR_Name[i];
                // memcpy(name[i], dir->DIR_Name[i], 1);
                i++;
            }
            if (dir->DIR_Name[8] == ' ')
                ;
            else
            {
                name[i] = '.';
                i++;
                if (dir->DIR_Name[8] != ' ')
                {
                    name[i] = dir->DIR_Name[8];
                    i++;
                }
                if (dir->DIR_Name[9] != ' ')
                {
                    name[i] = dir->DIR_Name[9];
                    i++;
                }
                if (dir->DIR_Name[10] != ' ')
                {
                    name[i] = dir->DIR_Name[10];
                    i++;
                }
            }
            name[i] = '\0';

            if (strncmp((char *)(file_name + 1), (char *)(name + 1), 11) != 0)
            {
                // not the same file
                count++;
                dir++;
                free(name);
                continue;
            }

            // recovery check sha1
            if (has_sha)
            {
                if (flag == 'R')
                {
                    unsigned int st_cluster = dir->DIR_FstClusHI << 16 | dir->DIR_FstClusLO;
                    unsigned int file_size = dir->DIR_FileSize;

                    unsigned int *fat = (unsigned int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size);

                    int del_clusters[19];
                    int count = 0;
                    for (int i = boot->BPB_RootClus; i <= 20; i++)
                    {
                        if (fat[i] == 0 && fat[i] != st_cluster)
                        {
                            del_clusters[count] = i;
                            count++;
                        }
                    }

                    int num_del_clusters = file_size / cluster_size;
                    if (file_size % cluster_size) num_del_clusters ++;
                    
                    int result[num_del_clusters];
                    result[0] = st_cluster;

                    if (recurse(del_clusters, result, 0, num_del_clusters, file_size) == 1)
                    {
                        // modify ƒirst character of filename to restore file
                        dir->DIR_Name[0] = file_name[0];

                        // for (int p = 0; p < num_del_clusters; p++) {
                        //     printf("%d*", result[p]);
                        // }
                        // printf("\n");

                        if (file_size == 0) // handle empty files
                        {
                            printf("%s: successfully recovered with SHA-1\n", file_name);
                            free(name);
                            return;
                        }

                        for (int cur_fat = 0; cur_fat < boot->BPB_NumFATs; cur_fat++)
                        {
                            int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + cur_fat * sector_size * boot->BPB_FATSz32);

                            int n;
                            for (n = 0; n < num_del_clusters - 1; n++)
                            {
                                fat[result[n]] = result[n + 1];
                            }
                            fat[result[n]] = 0x0FFFFFFF;
                        }

                        printf("%s: successfully recovered with SHA-1\n", file_name);

                        free(name);
                        return;
                    }
                }
                else
                {
                    unsigned int st_cluster = dir->DIR_FstClusHI << 16 | dir->DIR_FstClusLO;
                    unsigned int file_size = dir->DIR_FileSize;

                    unsigned char *cluster = (unsigned char *)disk +
                                             boot->BPB_RsvdSecCnt * sector_size +
                                             boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size +
                                             (st_cluster - 2) * cluster_size;

                    unsigned char file_sha1[SHA_DIGEST_LENGTH];
                    SHA1(cluster, file_size, file_sha1);

                    if (strncmp((char *)file_sha1, (char *)sha1, SHA_DIGEST_LENGTH) == 0)
                    {
                        // sha1 is the same!
                        del_dir = dir;
                        free(name);
                        break;
                    }
                }
            }
            else // no sha1 supplied
            {
                if (del_dir != NULL)
                {
                    printf("%s: multiple candidates found\n", file_name);
                    free(name);
                    return;
                }
                del_dir = dir;
            }
            free(name);
            count++;
            dir++;
        }
    } while ((root_dir_cluster = fat[root_dir_cluster]) < 0x0FFFFFF8);

    if (del_dir != NULL)
    {
        // modify ƒirst character of filename to restore file
        del_dir->DIR_Name[0] = file_name[0];

        unsigned int st_cluster = del_dir->DIR_FstClusHI << 16 | del_dir->DIR_FstClusLO; // start cluster of deleted file
        unsigned int file_size = del_dir->DIR_FileSize;                                  // file size of deleted file

        // dealing with empty file
        if (file_size == 0)
        {
            ;
        }
        else
        {
            int num_cluster_restored = 0;

            for (int cur_fat = 0; cur_fat < boot->BPB_NumFATs; cur_fat++)
            {
                int *fat = (int *)((char *)disk + boot->BPB_RsvdSecCnt * sector_size + cur_fat * sector_size * boot->BPB_FATSz32);

                num_cluster_restored = 0;
                while ((num_cluster_restored + 1) * cluster_size < file_size)
                {
                    // current cluster points to next cluster
                    fat[st_cluster + num_cluster_restored] = st_cluster + num_cluster_restored + 1;
                    num_cluster_restored++;
                }
                fat[st_cluster + num_cluster_restored] = 0x0FFFFFFF; // ending
            }
        }

        if (has_sha)
            printf("%s: successfully recovered with SHA-1\n", file_name);
        else
            printf("%s: successfully recovered\n", file_name);
        return;
    }

    printf("%s: file not found\n", file_name);
}

int recurse(int *possibilities, int *result, int cur, int size, unsigned int file_size)
{
    if (cur == size)
    {
        unsigned char test_file[cluster_size * 5]; // file content occupies no more than 5 clusters
        for (int i = 0; i < size; i++)
        {
            char *cluster = (char *)disk +
                            boot->BPB_RsvdSecCnt * sector_size +
                            boot->BPB_NumFATs * boot->BPB_FATSz32 * sector_size +
                            (result[i] - 2) * cluster_size;

            memcpy(test_file + i * cluster_size, cluster, cluster_size);
        }

        unsigned char file_sha1[SHA_DIGEST_LENGTH];
        SHA1(test_file, file_size, file_sha1);

        if (strncmp((char *)file_sha1, (char *)sha1, SHA_DIGEST_LENGTH) == 0)
        {
            return 1;
        }
        return 0;
    }
    for (int i = 0; i < size; i++)
    {
        int temp;

        if (possibilities[i] == -1)
            continue;

        temp = possibilities[i];
        result[cur] = temp;

        possibilities[i] = -1;

        if (recurse(possibilities, result, cur + 1, size, file_size) == 1)
            return 1;
        possibilities[i] = temp;
    }

    // if (cur == 1)
    return 0;
}