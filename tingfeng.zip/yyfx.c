#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define MAX_TOKEN_LENGTH 90
#define MAX_LEN 50
#define MAX_TOKEN_NUM 10000 

#define MAX_VARS 100
#define NAME_LENGTH 100

// 定义单词类别码的字符串表示
const char *token_names[] = {
    "IDENFR", "INTCON", "STRCON", "CHRCON", "MAINTK", 
	"CONSTTK", "INTTK", "CHARTK", "BREAKTK", "CONTINUETK", "IFTK", "ELSETK",
    "NOT", "AND", "OR", "FORTK", "GETINTTK", "GETCHARTK", "PRINTFTK", 
	"RETURNTK", "PLUS", "MINU", "VOIDTK",
    "MULT", "DIV", "MOD", "LSS", "LEQ", 
	"GRE", "GEQ", "EQL", "NEQ", "ASSIGN",
    "SEMICN", "COMMA", "LPARENT", "RPARENT", 
	"LBRACK", "RBRACK", "LBRACE", "RBRACE"
};

// 定义单词类别枚举
typedef enum {
    IDENFR, INTCON, STRCON, CHRCON, MAINTK, CONSTTK, INTTK, CHARTK, BREAKTK, CONTINUETK, IFTK, ELSETK,
    NOT, AND, OR, FORTK, GETINTTK, GETCHARTK, PRINTFTK, RETURNTK, PLUS, MINU, VOIDTK,
    MULT, DIV, MOD, LSS, LEQ, GRE, GEQ, EQL, NEQ, ASSIGN,
    SEMICN, COMMA, LPARENT, RPARENT, LBRACK, RBRACK, LBRACE, RBRACE
} TokenType;

// 定义单词结构
typedef struct {
    TokenType type;
    char value[MAX_TOKEN_LENGTH];
    char syntax_marker[MAX_LEN][MAX_TOKEN_LENGTH]; 
    int marker_count;  				// 语法标记
    int line_count; 
} Token;
// 定义关键字
typedef struct {
    const char *keyword;
    TokenType type;
} Keyword;

Keyword keywords[] = {
    {"const", CONSTTK}, {"int", INTTK}, {"void", VOIDTK}, {"main", MAINTK},
    {"char", CHARTK},
    {"if", IFTK}, {"else", ELSETK}, {"for", FORTK}, {"getint", GETINTTK},
    {"getchar", GETCHARTK}, {"printf", PRINTFTK}, {"break", BREAKTK},
    {"return", RETURNTK}, {"continue", CONTINUETK},{"Ident", IDENFR},
    {"IntConst",INTCON}, {"StringConst",STRCON}, {"CharConst", CHRCON}
};

#define KEYWORDS_NUM (sizeof(keywords) / sizeof(Keyword))

typedef struct {
    char name[NAME_LENGTH];
    char type[NAME_LENGTH];
    int scope_level; // 作用域序号
} Variable;


typedef struct {
    int line_count;  
    char error_type;  
    char error_massage[100];  
} Error;

Error error_forms[100]; 
int error_count = 0;    

int current_scope_level = 1; // 初始化全局作用域为 1
Variable variables[MAX_VARS];
int var_count = 0;
int size=0;
int tt=2;
int brace_count = 0;

// 存储所有词法单元
Token token_forms[MAX_TOKEN_NUM];
int token_count = 0; 
int current_token = 0;   
int error_flag = 0;

// 函数声明
void next_token();
void match(int type);
int judge_decl();
int judge_func_def();
int judge_func_formal_params();
int judge_block_item();
int judge_assign_stmt();
int judge_for_stmt();
int judge_stmt();
int judge_cond();
int judge_lor_exp();
int judge_land_exp();
int judge_eq_exp();
int judge_rel_exp();
int judge_exp();
int judge_const_exp();
int judge_add_exp();
int judge_unary_exp();
int judge_mul_exp();
int judge_lval();
int judge_prim_exp();
int judge_func_real_params();
int judge_const_decl();
int judge_var_decl();
int judge_var_def();
int judge_btype();
void parse_decl(); 
void parse_func_def();
void parse_block();
void parse_stmt();
void parse_func_type();
void parse_func_formal_params();
void parse_func_formal_param();
void parse_block_item();
void parse_assign_stmt();
void parse_if_stmt();
void parse_for_stmt();
void parse_for_stmt_part();
void parse_btype();
void parse_cond();
void parse_lor_exp();
void parse_land_exp();
void parse_exp();
void parse_lval();
void parse_eq_exp();
void parse_rel_exp();
void parse_const_decl();
void parse_var_decl();
void parse_return_stmt();
void parse_printf_stmt();
void parse_empty_stmt();
void parse_var_def();
void parse_const_def();
void parse_add_exp();
void parse_const_exp();
void parse_init_val();
void parse_const_init_val();
void parse_mul_exp();
void parse_unary_exp();
void parse_func_real_params();
void parse_primary_exp();
void parse_main();
void parse_getint();
void parse_getchar();
void add_error(int line_count, char error_type, const char* massage);
int compare_errors(const void *a, const void *b);
void output_errors();
void check_semicn();
void check_right_rparent();
void check_right_bracket();
void add_marker(const char *marker);
void add_variable(const char *name, const char *type, int scope_level);
int count_left_braces(const char *line) ;
int count_right_braces(const char *line) ;
int is_substring_in_quotes(const char *str, const char *substr);
void parse_file(const char *filename);
int compare(const void *a, const void *b) ;
void sort_variables();
void output_variables();
void parse_function(char *line, const char *type);
void parse_array(char *line, const char *type);
void parse_declaration(char *line, const char *type);
int starts_with(const char *line, const char *target); 

// 判断关键字
int is_keyword(const char *str) {
    int i=0;
    for (i = 0; i < KEYWORDS_NUM; i++) {
        if (strcmp(keywords[i].keyword, str) == 0) {
            return 1;
        }
    }
    return 0;
}

// 获取关键字token
TokenType get_keyword(const char *str) {
    int i=0;
    for (i = 0; i < KEYWORDS_NUM; i++) {
        if (strcmp(keywords[i].keyword, str) == 0) {
            return keywords[i].type;
        }
    }
    return IDENFR;
}

// 添加token
void add_token(TokenType type, const char *value, int line_count) {
    if (token_count < MAX_TOKEN_NUM) {
        token_forms[token_count].type = type;
        strncpy(token_forms[token_count].value, value, MAX_TOKEN_LENGTH);
        token_forms[token_count].line_count = line_count;  // 记录行号
        token_count++;
    }
}

// 输出tokens 
void output_tokens() {
    FILE *parserFile = fopen("parser.txt", "w");
    int i=0;
    for (i = 0; i < token_count; i++) {
        fprintf(parserFile, "%s %s\n", token_names[token_forms[i].type], token_forms[i].value);
        // 输出所有语法标记
        for (int j = 0; j < token_forms[i].marker_count; j++) {
            fprintf(parserFile, "%s\n", token_forms[i].syntax_marker[j]);
        }
    }
    fclose(parserFile);
}

// 打印错误信息
void output_error(int line, const char *error_type) {
    FILE *errorFile = fopen("error.txt", "w");
    fprintf(errorFile, "%d %s\n", line, error_type);
    fclose(errorFile);
    error_flag = 1;
}

// 从文件中读取输入源程序
void read_in(const char *filename, char *output) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return;
    }
    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        strcat(output, line);
    }
    fclose(file);
}

void next_token() {
    if (current_token < token_count) {
        current_token++; 
    }
}

void match(int type) {
    if (token_forms[current_token].type == type) {
        next_token();  
    } else {
        printf("未定义token\n");  
    }
}


int judge_decl() {
    return judge_const_decl() || judge_var_decl();
}

int judge_func_def() {
    return (token_forms[current_token].type == VOIDTK || token_forms[current_token].type == INTTK || token_forms[current_token].type == CHARTK) && token_forms[current_token+1].type == IDENFR && token_forms[current_token+2].type == LPARENT;
}

// 判断当前 token 是否为函数形参
int judge_func_formal_params() {
    return token_forms[current_token].type == INTTK || token_forms[current_token].type == CHARTK;
}

// 判断当前 token 是否为语句块项 
int judge_block_item() {
    return judge_decl() || judge_stmt();  
}

int judge_assign_stmt() {
    int k=0;
    while (token_forms[current_token+k].type != SEMICN){
        if (token_forms[current_token+k].type == ASSIGN){
            return 1;
        }
        k++;
    }
    return 0;
}

// 判断 for 循环中的赋值语句
int judge_for_stmt() {
    return token_forms[current_token].type == IDENFR;
}

int judge_stmt() {
    return token_forms[current_token].type == IDENFR ||  
    	   token_forms[current_token].type == INTCON ||  
		   judge_exp()||
    	   token_forms[current_token].type == SEMICN ||
    	   token_forms[current_token].type == LBRACE || 
           token_forms[current_token].type == IFTK ||    
           token_forms[current_token].type == FORTK || 
		   token_forms[current_token].type == BREAKTK || 
		   token_forms[current_token].type == CONTINUETK || 
		   token_forms[current_token].type == RETURNTK ||  
           token_forms[current_token].type == GETINTTK || 
           token_forms[current_token].type == GETCHARTK || 
           token_forms[current_token].type == PRINTFTK ;
}

int judge_cond() {
    return judge_lor_exp(); 
}

int judge_lor_exp() {
    if (judge_land_exp()) {  
        while (token_forms[current_token].type == OR) {  
            next_token(); 
            if (!judge_land_exp()) { 
                return 0;  
            }
        }
        return 1;  
    }
    return 0;  
}

int judge_land_exp() {
    if (judge_eq_exp()) { 
        while (token_forms[current_token].type == AND) { 
            next_token(); 
            if (!judge_eq_exp()) { 
                return 0; 
            }
        }
        return 1; 
    }
    return 0; 
}

int judge_eq_exp() {
    if (judge_rel_exp()) { 
        while (token_forms[current_token].type == EQL || token_forms[current_token].type == NEQ) { 
            next_token();  
            if (!judge_rel_exp()) { 
                return 0;  
            }
        }
        return 1; 
    }
    return 0;  
}

int judge_rel_exp() {
    if (judge_add_exp()) {  
        while (token_forms[current_token].type == LEQ|| token_forms[current_token].type == GRE ||
               token_forms[current_token].type == LSS || token_forms[current_token].type == GEQ) {  
            next_token();  
            if (!judge_add_exp()) {  
                return 0;  
            }
        }
        return 1;  
    }
    return 0; 
}

int judge_exp() {
    return judge_add_exp();  
}

int judge_const_exp() {
    return judge_add_exp(); 
}

int judge_add_exp() {
    int tmp = current_token;
    if (judge_mul_exp()) {  
        while (token_forms[current_token].type == PLUS || token_forms[current_token].type == MINU) { 
            next_token();  
            if (!judge_mul_exp()) {  
                current_token = tmp;
                return 0; 
            }
        }
        current_token = tmp;
        return 1; 
    }
    return 0;
}

int judge_unary_exp() {
    if (judge_prim_exp()) {  
        return 1;
    } else if (token_forms[current_token].type == IDENFR && token_forms[current_token+1].type == LPARENT) {
            return 1;
    } else if (token_forms[current_token].type == PLUS || token_forms[current_token].type == MINU || token_forms[current_token].type == NOT) {  // 检查是否是 UnaryOp
        return 1;
    }
    return 0;  
}

int judge_mul_exp() {
    int tmp = current_token;
    if (judge_unary_exp()) {  
        while (token_forms[current_token].type == MULT || token_forms[current_token].type == DIV || token_forms[current_token].type == MOD) {
            next_token();  
            if (!judge_unary_exp()) { 
                current_token = tmp;
                return 0; 
            }
        }
        current_token = tmp;
        return 1; 
    }
    return 0; 
}

int judge_lval() {
    if (token_forms[current_token].type == IDENFR) { 
        int tmp = current_token;
        next_token(); 
        if (token_forms[current_token].type == LBRACK) { 
            next_token(); 
            if (judge_exp()) {  
                current_token = tmp;
                return 1;
            } else {
                current_token = tmp;
                return 0;
            }
        }
        current_token = tmp;
        return 1; 
    }
    return 0; 
}

int judge_prim_exp() {
    if (token_forms[current_token].type == LPARENT) { 
        return 1;
    } else if (judge_lval()) { 
        return 1;
    } else if (token_forms[current_token].type == INTCON || token_forms[current_token].type == CHRCON) { 
        return 1;
    } else {
        // 错误处理：不合法的 PrimaryExp
        return 0;
    }
}

int judge_func_real_params() {
    if (judge_exp()) { 
        while (token_forms[current_token].type == COMMA) { 
            next_token();  
            if (!judge_exp()) { 
                return 0;  
            }
        }
        return 1; 
    }
    return 0;  
}

int judge_const_decl() {
    if (token_forms[current_token].type == CONSTTK) {
        current_token++; 
        if (judge_btype()) {
            current_token--;
            return 1; 
        }
        current_token--; 
    }
    return 0;  
}

int judge_var_decl() {
    if (judge_btype()) {
        if (token_forms[current_token+1].type == IDENFR && token_forms[current_token+2].type != LPARENT){
            return 1;
        }
    }
    return 0;
}

int judge_var_def() {
    return token_forms[current_token].type == IDENFR;
}

int judge_btype() {
    return token_forms[current_token].type == INTTK || token_forms[current_token].type == CHARTK;
}

void parse_decl() {
    if (token_forms[current_token].type == CONSTTK) {
        parse_const_decl();
    } else {
        parse_var_decl();
    }
}


void parse_func_def() {
    parse_func_type();  
    match(IDENFR);  
    match(LPARENT);
    if (judge_func_formal_params()) {
        parse_func_formal_params();  
    }
    if (token_forms[current_token].type == RPARENT){
        match(RPARENT); 
    }else{
        add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
    }
    parse_block(); 
    add_marker("<FuncDef>");
}

void parse_block() {
    match(LBRACE);  
    while (judge_block_item()) {
        parse_block_item();  
    }
    match(RBRACE);  
    add_marker("<Block>");
}

void parse_stmt() {
    if (token_forms[current_token].type == IDENFR &&
        token_forms[current_token+1].type != LPARENT &&
        token_forms[current_token+1].type != SEMICN &&
        judge_assign_stmt()) { 
        parse_assign_stmt(); 
        
        if (token_forms[current_token].type != SEMICN) {
            add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
        }else{
            match(SEMICN);
        }
    }
    else if (token_forms[current_token].type == IFTK) {
        parse_if_stmt();  
    }
    else if (token_forms[current_token].type == FORTK) {
        parse_for_stmt(); 
    }
    else if (token_forms[current_token].type == RETURNTK) {
        parse_return_stmt();  
    }
    else if (token_forms[current_token].type == PRINTFTK) {
        parse_printf_stmt(); 
    }
    else if (token_forms[current_token].type == BREAKTK) {
        next_token(); 
        if (token_forms[current_token].type == SEMICN) {
            next_token(); 
        } else {
            add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
        }
    }
    // 匹配 continue 语句
    else if (token_forms[current_token].type == CONTINUETK) {
        next_token();  
        if (token_forms[current_token].type == SEMICN) {
            next_token(); 
        } else {
            add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
        }
    }
    // 匹配 Block 语句
    else if (token_forms[current_token].type == LBRACE) {
        parse_block();  
    }
    // 匹配 [Exp] ';' 或者空语句 ';'
    else if (token_forms[current_token].type == SEMICN) {
        next_token(); 
    } else {
        parse_exp(); 
        if (token_forms[current_token].type == SEMICN) {
            next_token(); 
        } else {
            add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
        }
    }
    add_marker("<Stmt>");
}


void parse_func_type() {
    if (token_forms[current_token].type == VOIDTK ||
        token_forms[current_token].type == INTTK ||
        token_forms[current_token].type == CHARTK) {
        next_token();  
        add_marker("<FuncType>");
    } else {
        printf("缺少函数类型\n");
    }
}

// 解析函数形参
void parse_func_formal_params() {
    parse_func_formal_param(); 
    while (token_forms[current_token].type == COMMA) {  
        next_token();  
        parse_func_formal_param();  
    }
    add_marker("<FuncFParams>");
}

void parse_func_formal_param() {
    parse_btype();
    match(IDENFR); 
    if (token_forms[current_token].type == LBRACK) { 
        next_token();
        check_right_bracket(); 
    }
    add_marker("<FuncFParam>");
}
// 解析语句块中项
void parse_block_item() {
    if (judge_decl()) {
        parse_decl();  
    } else if (judge_stmt()) {
        parse_stmt(); 
    }
}

void parse_assign_stmt() {
    parse_lval(); 
    if (token_forms[current_token].type == ASSIGN) {
        next_token();  
        if (token_forms[current_token].type == GETINTTK) {
            parse_getint();
        } else if (token_forms[current_token].type == GETCHARTK) {
            parse_getchar();
        } else {
            
            parse_exp();
        }
    } else {
        printf("缺少等号\n");
    }
}


void parse_if_stmt() {
    match(IFTK);  
    match(LPARENT); 
    parse_cond(); 
    check_right_rparent();
    parse_stmt();  
    if (token_forms[current_token].type == ELSETK) {  
        next_token();  
        parse_stmt();  
    }
}


void parse_for_stmt() {
    match(FORTK);  
    match(LPARENT);  
    if (judge_for_stmt()) {
        parse_for_stmt_part();  
    }
    match(SEMICN);  
    if (judge_cond()) {
        parse_cond();  
    }
    match(SEMICN); 
    if (judge_for_stmt()) {
        parse_for_stmt_part(); 
    }
    match(RPARENT); 
    parse_stmt(); 
}


// 解析 for 循环的初始语句
void parse_for_stmt_part() {
    parse_assign_stmt(); 
    add_marker("<ForStmt>");

}

void parse_btype() {
    if (token_forms[current_token].type == INTTK ||
        token_forms[current_token].type == CHARTK) {
        next_token();  
    } else {
        printf("缺少基本类型\n");
    }
}

void parse_cond() {
    parse_lor_exp();  
    add_marker("<Cond>");
}

void parse_lor_exp() {
    parse_land_exp();  
    while (token_forms[current_token].type == OR) {  
        add_marker("<LOrExp>");
        next_token(); 
        parse_land_exp();  
    }
    add_marker("<LOrExp>");
}
void parse_land_exp() {
    parse_eq_exp();  
    while (token_forms[current_token].type == AND) {  
        add_marker("<LAndExp>");
        next_token();  
        parse_eq_exp(); 
    }
    add_marker("<LAndExp>");
}

void parse_exp() {
    parse_add_exp();  
    add_marker("<Exp>");
}

void parse_lval() {
    match(IDENFR);  
    if (token_forms[current_token].type == LBRACK) {  
        next_token();
        parse_exp(); 
        check_right_bracket();
    }
    add_marker("<LVal>");
}

void parse_eq_exp() {
    parse_rel_exp(); 
    while (token_forms[current_token].type == EQL || token_forms[current_token].type == NEQ) {
        add_marker("<EqExp>");
        next_token();  
        parse_rel_exp();  
    }
    add_marker("<EqExp>");
}

void parse_rel_exp() {
    parse_add_exp(); 
    while (token_forms[current_token].type == LSS ||
           token_forms[current_token].type == GRE ||
           token_forms[current_token].type == LEQ ||
           token_forms[current_token].type == GEQ) {
        add_marker("<RelExp>"); 
        next_token(); 
        parse_add_exp();  
    }
    add_marker("<RelExp>");
}

void parse_const_decl() {
    match(CONSTTK); 
    parse_btype();  
    parse_const_def(); 
    while (token_forms[current_token].type == COMMA) {  
        next_token(); 
        parse_const_def();
    }
    if (token_forms[current_token].type != SEMICN) {
        add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
    }else{
        match(SEMICN); 
    }
    add_marker("<ConstDecl>");
}

void parse_var_decl() {
    parse_btype();  
    parse_var_def(); 
    while (token_forms[current_token].type == COMMA) {  
        next_token(); 
        parse_var_def();  
    }
    if (token_forms[current_token].type != SEMICN) {
        add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
    }else{
        match(SEMICN); 
    }
    add_marker("<VarDecl>");
}

void parse_return_stmt() {
    match(RETURNTK); 
    if (judge_exp()) {  
        parse_exp();
    }
    check_semicn();
}

void parse_printf_stmt() {
    match(PRINTFTK); 
    match(LPARENT); 
    match(STRCON);   
    while (token_forms[current_token].type == COMMA) {  
        next_token(); 
        parse_exp();   
    }
    check_right_rparent();
    check_semicn();
    
}

void parse_empty_stmt() {
    match(SEMICN); 
}

void parse_var_def() {
    match(IDENFR);  
    if (token_forms[current_token].type == LBRACK) {  
        match(LBRACK); 
        parse_const_exp();  
        check_right_bracket();  
    }
    if (token_forms[current_token].type == ASSIGN) { 
        match(ASSIGN);  
        parse_init_val(); 
    }
    add_marker("<VarDef>");
}

void parse_const_def() {
    match(IDENFR);  
    if (token_forms[current_token].type == LBRACK) { 
        match(LBRACK);  
        parse_const_exp(); 
        check_right_bracket(); 
    }
    match(ASSIGN);  
    parse_const_init_val();  
    add_marker("<ConstDef>");
}

void parse_add_exp() {
    parse_mul_exp();  
    while (token_forms[current_token].type == PLUS || token_forms[current_token].type == MINU) {
        add_marker("<AddExp>");
        next_token();  
        parse_mul_exp();  
    }
    add_marker("<AddExp>");
}


void parse_main(){
    if (token_forms[current_token].type == INTTK) { 
        next_token();  
    } else {
        printf("缺少int\n");
        return;
    }
    if (token_forms[current_token].type == MAINTK) {  
        next_token(); 
    } else {
        printf("缺少main\n");
        return;
    }

    if (token_forms[current_token].type == LPARENT) {  
        next_token(); 
    } else {
        printf("缺少左小括号\n");
        return;
    }

    check_right_rparent();

    // 解析语句块 Block
    if (token_forms[current_token].type == LBRACE) { 
        parse_block();  
        add_marker("<MainFuncDef>");
    } else {
        printf("缺少左大括号\n");
        return;
    }
}


void parse_getint() {
    next_token(); 
    if (token_forms[current_token].type == LPARENT) {
        next_token();  
        if (token_forms[current_token].type == RPARENT) {
            next_token(); 
        } else {
            printf("缺少右小括号\n");
            add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
        }
    } else {
        printf("缺少左小括号\n");
    }
}

void parse_getchar() {
    next_token(); 
    if (token_forms[current_token].type == LPARENT) {
        next_token(); 
        if (token_forms[current_token].type == RPARENT) {
            next_token();  
        } else {
            printf("缺少右小括号\n");
            add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
        }
    } else {
        printf("缺少左小括号\n");
    }
}

void parse_const_exp() {
    parse_add_exp();  
    add_marker("<ConstExp>");
}

void parse_init_val() {
    if (token_forms[current_token].type == LBRACE) {  
        match(LBRACE);  
        if (judge_exp()) {  
            parse_exp(); 
            while (token_forms[current_token].type == COMMA) {  
                next_token(); 
                parse_exp(); 
            }
        }
        match(RBRACE);  
    } else if (token_forms[current_token].type == STRCON) {  
        match(STRCON);  
    } else {
        parse_exp();  
    }
    add_marker("<InitVal>");
}

void parse_const_init_val() {
    if (token_forms[current_token].type == LBRACE) {  
        match(LBRACE);  
        if (judge_const_exp()) { 
            parse_const_exp();  
            while (token_forms[current_token].type == COMMA) {  
                next_token(); 
                parse_const_exp();  
            }
        }
        match(RBRACE); 
    } else if (token_forms[current_token].type == STRCON) { 
        match(STRCON); 
    } else {
        parse_const_exp(); 
    }
    add_marker("<ConstInitVal>");
}

void parse_mul_exp() {
    if (judge_unary_exp()) {  
        parse_unary_exp();  
    }
    // 检查运算符
    while (token_forms[current_token].type == MULT || token_forms[current_token].type == DIV || token_forms[current_token].type == MOD) {
        add_marker("<MulExp>"); 
        next_token();  
        parse_unary_exp(); 
    }
    add_marker("<MulExp>");
}





void parse_unary_exp() {

    if (token_forms[current_token].type == IDENFR &&
        token_forms[current_token+1].type == LPARENT ) {  
        next_token(); 
        
        if (token_forms[current_token].type == LPARENT) {  
            next_token();  
            if (judge_func_real_params()) {  
                parse_func_real_params(); 
            }
            if (token_forms[current_token].type == RPARENT) {  
                next_token();  
            }else{
                add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
            }
        }
    } else if (token_forms[current_token].type == PLUS || token_forms[current_token].type == MINU || token_forms[current_token].type == NOT) {  // UnaryOp
        next_token(); 
        add_marker("<UnaryOp>");
        parse_unary_exp();
    } else if (judge_prim_exp()){
        parse_primary_exp();  
    }
    add_marker("<UnaryExp>");
}





void parse_primary_exp() {
    if (token_forms[current_token].type == LPARENT) { 
        next_token();  
        parse_exp(); 
        if (token_forms[current_token].type == RPARENT) { 
            next_token(); 
        } else {
            add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
        }
    } else if (judge_lval()) { 
        parse_lval(); 
    } else if (token_forms[current_token].type == INTCON){ 
        next_token();
        add_marker("<Number>");
    } else if (token_forms[current_token].type == CHRCON){
        next_token();
        add_marker("<Character>");
    } else {
        printf("error_PrimaryExp");
    }
    add_marker("<PrimaryExp>");
}



void parse_func_real_params() {
    parse_exp();  
    while (token_forms[current_token].type == COMMA) {
        next_token();  
        parse_exp();  
    }
    add_marker("<FuncRParams>");
}

void add_error(int line_count, char error_type, const char* massage) {
    error_forms[error_count].line_count = line_count;
    error_forms[error_count].error_type = error_type;
    strcpy(error_forms[error_count].error_massage, massage);
    error_count++;
}
void output_errors() {
    qsort(error_forms, error_count, sizeof(Error), compare_errors);
    FILE *errorFile = fopen("error.txt", "w");
    int i;
    for (i = 0; i < error_count; i++) {
        fprintf(errorFile, "%d %c\n", error_forms[i].line_count, error_forms[i].error_type);
    }
    fclose(errorFile);
}
int compare_errors(const void *a, const void *b) {
    Error *errorA = (Error *)a;
    Error *errorB = (Error *)b;
    return errorA->line_count - errorB->line_count;
}



void add_marker(const char *marker) {
    if (token_forms[current_token-1].marker_count < MAX_LEN) {
        strncpy(token_forms[current_token-1].syntax_marker[token_forms[current_token-1].marker_count], marker, MAX_TOKEN_LENGTH);
        token_forms[current_token-1].marker_count++;
    }
}
//检查分号
void check_semicn() { 
    if (token_forms[current_token].type != SEMICN) {
        add_error(token_forms[current_token - 1].line_count, 'i', "缺少分号 ';'");
    }else {
        current_token++; 
    }
}
//检查右小括号
void check_right_rparent() { 
    if (token_forms[current_token].type != RPARENT) {
        add_error(token_forms[current_token - 1].line_count, 'j', "缺少右括号 ')'");
    }else {
        current_token++;  
    }
}
//检查是右中括号
void check_right_bracket() { 
    if (token_forms[current_token].type != RBRACK) {
        add_error(token_forms[current_token - 1].line_count, 'k', "缺少右中括号 ']'");
    }else {
        current_token++;  
    }
}



// 语法分析
void parse() {
    while (judge_decl()) {
        parse_decl(); 
    }
    while (judge_func_def()) {
        parse_func_def(); 
    }
    parse_main();
    add_marker("<CompUnit>");  
}




// 词法分析
void lexical_analysis(const char *in) {
    int i = 0, line = 1;
    char tmp_list[MAX_TOKEN_LENGTH];
    
    while (in[i] != '\0') {
        if (isspace(in[i])) {
            if (in[i] == '\n') line++;
            i++;
            continue;
        }
        // 处理行注释 
        if (in[i] == '/' && in[i + 1] == '/') {
            i += 2;
            while (in[i] != '\n' && in[i] != '\0') {
                i++;
            }
            if (in[i] == '\n'){
                line++;
                i++;
            }
            continue;
        }
        // 处理块注释 
        if (in[i] == '/' && in[i + 1] == '*') {
            i += 2;
            while (in[i] != '\0' && !(in[i] == '*' && in[i + 1] == '/')) {
                if (in[i] == '\n') line++;
                i++;
            }
            i += 2; 
            continue;
        }
        // 识别标识符或关键字
        if (isalpha(in[i]) || in[i] == '_') {
            int j = 0;
            while (isalnum(in[i]) || in[i] == '_') {
                tmp_list[j++] = in[i++];
            }
            tmp_list[j] = '\0';

            if (is_keyword(tmp_list)) {
                add_token(get_keyword(tmp_list), tmp_list, line);
            } else {
                add_token(IDENFR, tmp_list, line);
            }
        }
        // 识别数字常量
        else if (isdigit(in[i])) {
            int j = 0;
            while (isdigit(in[i])) {
                tmp_list[j++] = in[i++];
            }
            tmp_list[j] = '\0';
            add_token(INTCON, tmp_list, line);
        }
        // 识别字符串常量
        else if (in[i] == '"') 
		{
            int j = 0;
            tmp_list[j++] = in[i++];
            while (in[i] != '"' && in[i] != '\0') 
			{
                tmp_list[j++] = in[i++];
            }
            if (in[i] == '"') 
			{
                tmp_list[j++] = in[i++];
                tmp_list[j] = '\0';
                add_token(STRCON, tmp_list, line);
            }
        }
        // 识别字符常量
        else if (in[i] == '\'') 
		{
            int j = 0;
            tmp_list[j++] = in[i++];  
            if (in[i] == '\\') 
			{ 
                    tmp_list[j++] = in[i++]; 
                    if (in[i] != '\0' && in[i + 1] == '\'') 
					{
                        tmp_list[j++] = in[i++];  
                        tmp_list[j++] = in[i++]; 
                        tmp_list[j] = '\0';
                        add_token(CHRCON, tmp_list, line);  
                    }
            }
			else if (in[i] != '\0' && in[i + 1] == '\'') 
			{
                tmp_list[j++] = in[i++];  
                tmp_list[j++] = in[i++];  
                tmp_list[j] = '\0';
                add_token(CHRCON, tmp_list, line);
            }
        }
        // 识别运算符和分隔符
        else {
            switch (in[i]) {
                case '=':
                    if (in[i+1] == '=') {
                        add_token(EQL, "==", line);
                        i += 2;
                    } else {
                        add_token(ASSIGN, "=", line);
                        i++;
                    }
                    break;
                case '!':
                    if (in[i+1] == '=') {
                        add_token(NEQ, "!=", line);
                        i += 2;
                    } else {
                        add_token(NOT, "!", line);
                        i++;
                    }
                    break;
                case '&':
                    if (in[i+1] == '&') {
                        add_token(AND, "&&", line);
                        i += 2;
                    } else {
                        add_token(AND, "&", line);
                        add_error(line, 'a', "错误：'&'");
                        i++;
                    }
                    break;
                case '|':
                    if (in[i+1] == '|') {
                        add_token(OR, "||", line);
                        i += 2;
                    } else {
                        add_token(OR, "|", line);
                        add_error(line, 'a', "错误：'|'");
                        i++;
                    }
                    break;
                case '<':
                    if (in[i+1] == '=') {
                        add_token(LEQ, "<=", line);
                        i += 2;
                    } else {
                        add_token(LSS, "<", line);
                        i++;
                    }
                    break;
                case '>':
                    if (in[i+1] == '=') {
                        add_token(GEQ, ">=", line);
                        i += 2;
                    } else {
                        add_token(GRE, ">", line);
                        i++;
                    }
                    break;
                case '+':
                    add_token(PLUS, "+", line);
                    i++;
                    break;
                case '-':
                    add_token(MINU, "-", line);
                    i++;
                    break;
                case '*':
                    add_token(MULT, "*", line);
                    i++;
                    break;
                case '/':
                    add_token(DIV, "/", line);
                    i++;
                    break;
                case '%':
                    add_token(MOD, "%", line);
                    i++;
                    break;
                case ',':
                    add_token(COMMA, ",", line);
                    i++;
                    break;
                case ';':
                    add_token(SEMICN, ";", line);
                    i++;
                    break;
                case '(':
                    add_token(LPARENT, "(", line);
                    i++;
                    break;
                case ')':
                    add_token(RPARENT, ")", line);
                    i++;
                    break;
                case '[':
                    add_token(LBRACK, "[", line);
                    i++;
                    break;
                case ']':
                    add_token(RBRACK, "]", line);
                    i++;
                    break;
                case '{':
                    add_token(LBRACE, "{", line);
                    i++;
                    break;
                case '}':
                    add_token(RBRACE, "}", line);
                    i++;
                    break;
                case '\n':
                    line++;
                    i++;
                    break;
                default:
                    //output_error(line, "a");
                    i++;
                    break;
            }
        }
    }
//    printf("%s\n",tmp_list);
}

int count_left_braces(const char *line) {
    int count = 0;
    while (*line) {  // 遍历字符串直到结尾
        if (*line == '{') {
            count++;  // 如果是 '{'，计数器加 1
        }
        line++;  // 移动到下一个字符
    }
    return count;
}
int count_right_braces(const char *line) {
    int count = 0;
    while (*line) {  // 遍历字符串直到结尾
        if (*line == '}') {
            count++;  // 如果是 '{'，计数器加 1
        }
        line++;  // 移动到下一个字符
    }
    return count;
}
int is_substring_in_quotes(const char *str, const char *substr) {
    int in_quotes = 0;  // 标记是否在引号内
    const char *pos = strstr(str, substr);  // 查找子字符串的位置
    if (!pos) {
        return 0;  // 如果没有找到子字符串，返回0
    }

    // 遍历子字符串之前的部分，判断是否位于引号内
    for (const char *p = str; p < pos; p++) {
        if (*p == '"') {
            in_quotes = !in_quotes;  // 切换引号状态
        }
    }

    // 判断子字符串是否在引号内
    return in_quotes;
}
void trim_leading_spaces(char *str) {
    // 找到第一个非空格字符
    char *t=str;
    while (*str != '\0' && isspace((unsigned char)*str)) {
        str++;
    }

    // 将结果复制到新的字符串起始位置
    memmove(t, str, strlen(str) + 1);
    
}

void add_variable(const char *name, const char *type, int scope_level) {
    if (var_count < MAX_VARS) {
        strcpy(variables[var_count].name, name);
        strcpy(variables[var_count].type, type);
        variables[var_count].scope_level = scope_level;
        var_count++;
    }
}

void parse_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    char lines[1000][256];
    int lineCount = 0; // 行数计数
        // 读取多行输入
	while (lineCount < 1000 && fgets(lines[lineCount], 256, file) != NULL) {
	    lineCount++;
	}
	fclose(file);
	int in_multiline_comment = 0;
	printf("%d\n",in_multiline_comment);
	for(int i=0;i<lineCount;i++){
//		printf("%d %d %d\n",tt,current_scope_level,brace_count);
        lines[i][strcspn(lines[i], "\n")] = 0; // 去掉换行符
		trim_leading_spaces(lines[i]);//跳过开头空格 
        // 如果当前处于多行注释状态，则继续忽略该行
        if (in_multiline_comment) {
            char *multi_line_comment_end = strstr(lines[i], "*/");
            if (multi_line_comment_end != NULL) {
                *multi_line_comment_end = '\0'; // 截断注释部分
                in_multiline_comment = 0; // 结束多行注释
            } else {
                lines[i][0] = '\0'; // 如果多行注释未结束，则整行清空
            }
        }

        // 处理单行注释
        char *single_line_comment = strstr(lines[i], "//");
        if (single_line_comment != NULL) {
            *single_line_comment = '\0'; // 截断掉注释部分
        }

        // 处理多行注释开始符号
        if (!in_multiline_comment) {
            char *multi_line_comment_start = strstr(lines[i], "/*");
            if (multi_line_comment_start != NULL) {
                in_multiline_comment = 1; // 进入多行注释状态
                char *multi_line_comment_end = strstr(lines[i], "*/");
                if(multi_line_comment_end != NULL){
                	*multi_line_comment_end = '\0';
					in_multiline_comment = 0;
				}
				else{
					*multi_line_comment_start = '\0'; // 截断掉多行注释的开始部分
				}
                
            }
        }
	    
        // 跳过 main 函数
        if (strstr(lines[i], "main") != NULL && !is_substring_in_quotes(lines[i],"main")) {
        	tt=current_scope_level+1;
        	
        	if (strstr(lines[i], "{") != NULL){
        		current_scope_level++;
				brace_count++;
			}
        	
//        	printf("%d\n",current_scope_level);
            continue;
            
        }

//		printf("%s\n",lines[i]);
        // 检测各类变量和函数类型
        if (strncmp(lines[i], "const char ",strlen("const char ")) == 0) {
                // 处理变量声明和初始化
            char *declaration = lines[i] + strlen("const char ");
	        char *equal_sign = strchr(declaration, '=');
	        while (equal_sign != NULL) {
	                    // 如果有 {，表示是数组初始化，找到配对的 } 并忽略初始化内容
				char *after_equal = equal_sign + 1;
				while (*after_equal == ' ') {
				    after_equal++; // 跳过空格
				}
	            if (*after_equal == '{') {
	                char *brace_close = strchr(after_equal, '}');
	                if (brace_close != NULL) {
	                            // 忽略整个初始化部分
	                    memset(equal_sign, ' ', brace_close - equal_sign + 1); // 用空格覆盖初始化部分
	                }
	            }
	                    // 查找下一个 "="，继续处理
	            equal_sign = strchr(equal_sign + 1, '=');
	        }
                // 处理函数调用（检查是否有函数调用的情况）
            char *func_open = strchr(declaration, '(');
            if (func_open != NULL) {
                    // 有函数调用，跳过函数调用部分的参数
                char *func_close = strchr(func_open, ')');
                if (func_close != NULL) {
                        // 跳过函数调用的参数部分
                    memset(func_open, ' ', func_close - func_open + 1); // 用空格覆盖函数参数
                }
            }
            
            char *var_decl = strtok(declaration, ","); // 使用逗号分隔多个变量声明

            while (var_decl != NULL) {

                    // 判断是否是数组或常规变量声明
                if (strstr(var_decl, "[") != NULL && strstr(var_decl, "]") != NULL) {
                    char *equal = strchr(var_decl, '=');
                    if (equal != NULL){
						if (equal > strstr(var_decl, "]")){
							parse_declaration(var_decl, "ConstCharArray");
						}
						else{
							parse_declaration(var_decl, "ConstChar");
						}
					}
					else{
						parse_declaration(var_decl, "ConstCharArray");
					}
                } else {
                    parse_declaration(var_decl, "ConstChar");
                }

                var_decl = strtok(NULL, ","); // 获取下一个声明
            }
        } else if (strncmp(lines[i], "void ",strlen("void ")) == 0) {
		    parse_function(lines[i] + strlen("void "), "VoidFunc");
		} else if (strncmp(lines[i], "char ",strlen("char ")) == 0) {
			if(strstr(lines[i], "{") != NULL && strstr(lines[i], "=") == NULL){
				parse_function(lines[i] + strlen("char "), "CharFunc");
			} else if(lines[i+1][0]=='{'){
				parse_function(lines[i] + strlen("char "), "CharFunc");
			} else {
                // 处理变量声明和初始化
                char *declaration = lines[i] + strlen("char ");
                
		        char *equal_sign = strchr(declaration, '=');
		        while (equal_sign != NULL) {
		                    // 如果有 {，表示是数组初始化，找到配对的 } 并忽略初始化内容
					char *after_equal = equal_sign + 1;
					while (*after_equal == ' ') {
					    after_equal++; // 跳过空格
					}
		            if (*after_equal == '{') {
		                char *brace_close = strchr(after_equal, '}');
		                if (brace_close != NULL) {
		                            // 忽略整个初始化部分
		                    memset(equal_sign, ' ', brace_close - equal_sign + 1); // 用空格覆盖初始化部分
		                }
		            }
		                    // 查找下一个 "="，继续处理
		            equal_sign = strchr(equal_sign + 1, '=');
		        }
	            
                // 处理函数调用（检查是否有函数调用的情况）
	            char *func_open = strchr(declaration, '(');
	            if (func_open != NULL) {
	                    // 有函数调用，跳过函数调用部分的参数
	                char *func_close = strchr(func_open, ')');
	                if (func_close != NULL) {
	                        // 跳过函数调用的参数部分
	                    memset(func_open, ' ', func_close - func_open + 1); // 用空格覆盖函数参数
	                }
	            }
//	            printf("%s\n",declaration);
	            char *var_decl = strtok(declaration, ","); // 使用逗号分隔多个变量声明
                while (var_decl != NULL) {
//                	printf("%s\n",var_decl);

                    // 判断是否是数组或常规变量声明
                    if (strstr(var_decl, "[") != NULL && strstr(var_decl, "]") != NULL) {
	                    char *equal = strchr(var_decl, '=');
	                    if (equal != NULL){
							if (equal > strstr(var_decl, "]")){
								parse_declaration(var_decl, "CharArray");
							}
							else{
								parse_declaration(var_decl, "Char");
							}
						}
						else{
							parse_declaration(var_decl, "CharArray");
						}
                    } else {
                        parse_declaration(var_decl, "Char");
                    }

                    var_decl = strtok(NULL, ","); // 获取下一个声明
                }
            }
        } else if (strncmp(lines[i], "const int ",strlen("const int ")) == 0) {
                // 处理变量声明和初始化
            
            char *declaration = lines[i] + strlen("const int ");
	        char *equal_sign = strchr(declaration, '=');
	        while (equal_sign != NULL) {
	                    // 如果有 {，表示是数组初始化，找到配对的 } 并忽略初始化内容
				char *after_equal = equal_sign + 1;
				while (*after_equal == ' ') {
				    after_equal++; // 跳过空格
				}
	            if (*after_equal == '{') {
	                char *brace_close = strchr(after_equal, '}');
	                if (brace_close != NULL) {
	                            // 忽略整个初始化部分
	                    memset(equal_sign, ' ', brace_close - equal_sign + 1); // 用空格覆盖初始化部分
	                }
	            }
	                    // 查找下一个 "="，继续处理
	            equal_sign = strchr(equal_sign + 1, '=');
	        }

                // 处理函数调用（检查是否有函数调用的情况）
            char *func_open = strchr(declaration, '(');
            if (func_open != NULL) {
                    // 有函数调用，跳过函数调用部分的参数
                char *func_close = strchr(func_open, ')');
                if (func_close != NULL) {
                        // 跳过函数调用的参数部分
                    memset(func_open, ' ', func_close - func_open + 1); // 用空格覆盖函数参数
                }
            }
            char *var_decl = strtok(declaration, ","); // 使用逗号分隔多个变量声明

            while (var_decl != NULL) {
                    // 判断是否是数组或常规变量声明
                if (strstr(var_decl, "[") != NULL && strstr(var_decl, "]") != NULL) {
                    char *equal = strchr(var_decl, '=');
                    if (equal != NULL){
						if (equal > strstr(var_decl, "]")){
							parse_declaration(var_decl, "ConstIntArray");
						}
						else{
							parse_declaration(var_decl, "ConstInt");
						}
					}
					else{
						parse_declaration(var_decl, "ConstIntArray");
					}
                } else {
                    parse_declaration(var_decl, "ConstInt");
                }

                var_decl = strtok(NULL, ","); // 获取下一个声明
            }
        } else if (strncmp(lines[i], "int ",strlen("int ")) == 0) {
        	if(strstr(lines[i], "{") != NULL && strstr(lines[i], "=") == NULL){
				parse_function(lines[i] + strlen("int "), "IntFunc");
			} else if(lines[i+1][0]=='{'){
				parse_function(lines[i] + strlen("int "), "IntFunc");
				
			} else {
                // 处理变量声明和初始化
                char *declaration = lines[i] + strlen("int ");
	            char *equal_sign = strchr(declaration, '=');
	            while (equal_sign != NULL) {
	                    // 如果有 {，表示是数组初始化，找到配对的 } 并忽略初始化内容
				    char *after_equal = equal_sign + 1;
				    while (*after_equal == ' ') {
				        after_equal++; // 跳过空格
				    }
	                if (*after_equal == '{') {
	                    char *brace_close = strchr(after_equal, '}');
	                    if (brace_close != NULL) {
	                            // 忽略整个初始化部分
	                        memset(equal_sign, ' ', brace_close - equal_sign + 1); // 用空格覆盖初始化部分
	                    }
	                }
	                    // 查找下一个 "="，继续处理
	                equal_sign = strchr(equal_sign + 1, '=');
	            }
	            
                // 处理函数调用（检查是否有函数调用的情况）
	            char *func_open = strchr(declaration, '(');
	            if (func_open != NULL) {
	                    // 有函数调用，跳过函数调用部分的参数
	                char *func_close = strchr(func_open, ')');
	                if (func_close != NULL) {
	                        // 跳过函数调用的参数部分
	                    memset(func_open, ' ', func_close - func_open + 1); // 用空格覆盖函数参数
	                }
	            }
                char *var_decl = strtok(declaration, ","); // 使用逗号分隔多个变量声明

                while (var_decl != NULL) {
//                	printf("%s\n",var_decl);
                    // 去掉变量声明末尾的分号
                    // 判断是否是数组或常规变量声明
                    if (strstr(var_decl, "[") != NULL && strstr(var_decl, "]") != NULL) {
                    	char *equal = strchr(var_decl, '=');
                    	if (equal != NULL){
							if (equal > strstr(var_decl, "]")){
								parse_declaration(var_decl, "IntArray");
							}
							else{
								parse_declaration(var_decl, "Int");
							}
						}
						else{
							parse_declaration(var_decl, "IntArray");
						}
                        
                    } else {
                        parse_declaration(var_decl, "Int");
                    }

                    var_decl = strtok(NULL, ","); // 获取下一个声明
                }
            }
        } else if(count_left_braces(lines[i])){
//        	printf("%d\n",count_left_braces(lines[i]));
			current_scope_level+=count_left_braces(lines[i]);
			brace_count+=count_left_braces(lines[i]);
			if(strchr(lines[i],'}')!=NULL){
				brace_count-=count_right_braces(lines[i]);
			}
//			printf("%d %d %d\n",tt,current_scope_level,brace_count);
		} else if(count_right_braces(lines[i])){
			brace_count-=count_right_braces(lines[i]);
		} 
		
	}

}

void parse_function(char *line, const char *type){
	char name[NAME_LENGTH];
	char params[NAME_LENGTH] = {0};
	char *str=line;
	int tmp=count_left_braces(line);
	while(*line){
		if(*line == '('){
			*line = ' ';
		}
		line++;
	}
	line=str;
//	printf("%s\n",line);
    // 提取函数名和形参
    if (sscanf(line, "%s %[^)]", name, params) >= 1) {
        // 添加函数名
        add_variable(name, type, 1);
		size++;
		tt=current_scope_level+1;
        // 处理形参
        char *token = strtok(params, ",");
        while (token != NULL) {
            char var_name[NAME_LENGTH];
            char var_type[NAME_LENGTH];

            // 提取形参的类型和名称
            if (sscanf(token, "%s %s", var_type, var_name) == 2) {
            	if(strcmp(var_type,"int")==0){
		            char *paren1 = strchr(var_name, '[');
		            if (paren1) {
		                *paren1 = '\0'; // 去掉括号及后面的内容
		                add_variable(var_name, "IntArray", current_scope_level+1);
		                size++;
		            }
		            else{
						add_variable(var_name, "Int", current_scope_level+1);
						size++;
					}
				}
            	if(strcmp(var_type,"char")==0){
		            char *paren1 = strchr(var_name, '[');
		            if (paren1) {
		                *paren1 = '\0'; // 去掉括号及后面的内容
		                add_variable(var_name, "CharArray", current_scope_level+1);
		                size++;
		            }
		            else{
						add_variable(var_name, "Char", current_scope_level+1);
						size++;
					}
				}
                
            }
            token = strtok(NULL, ",");
        }
        if(tmp){
			current_scope_level+=tmp;
			brace_count+=tmp;
		}
    }
    
}

//void parse_array(char *line, const char *type) {
//	
//}


void parse_declaration(char *token, const char *type) {
	
    int paren_count = 0; // 用于计数括号
//    printf("%s\n",token);
        while (*token == ' ') token++; 
        char name[NAME_LENGTH];
        // 提取变量名，处理函数名
        
        if (sscanf(token, "%s", name) == 1) {
            // 去掉括号
//            char *paren = strchr(name, '(');
//            if (paren) {
//                *paren = '\0'; // 去掉括号及后面的内容
//            }
            char *paren1 = strchr(name, '[');
            if (paren1) {
                *paren1 = '\0'; // 去掉括号及后面的内容
            }
            char *paren2 = strchr(name, '=');
            if (paren2) {
                *paren2 = '\0'; // 去掉括号及后面的内容
            }
            char *semicolon = strchr(name, ';');
            if (semicolon != NULL) {
                *semicolon = '\0'; // 终止符设置为字符串结尾
            }
            for (char *p = name; *p != '\0'; p++) {
                if (*p == '(') {
                    paren_count++;
                } else if (*p == ')') {
                    paren_count--;
                }
            }
//            printf("%d\n",paren_count);
//           	printf("%d %d %d\n",tt,current_scope_level,brace_count);
			if(paren_count == 0){
				if(brace_count == 1){
					add_variable(name, type, tt);
					size++;
				} else{
					add_variable(name, type, current_scope_level);
					size++;
				}

			}
    }
}
int compare(const void *a, const void *b) {
	Variable *variableA = (Variable *)a;
	Variable *variableB = (Variable *)b;
	return variableA->scope_level - variableB->scope_level;  // 按年龄升序排序
}

// 冒泡排序函数（保持稳定性）
void bubbleSort(Variable arr[], int n) {
    int i, j;
    Variable tmp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            // 如果当前学生的成绩大于下一个学生的成绩，则交换
            if (arr[j].scope_level > arr[j + 1].scope_level) {
                tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
            }
            // 不需要交换相等的元素，保持原序列
        }
    }
}

void output_variables() {
	FILE *symbolFile = fopen("symbol.txt", "w");
	bubbleSort(variables, size);
    for (int i = 0; i < var_count; i++) {
        printf("%d %s %s\n", variables[i].scope_level, variables[i].name, variables[i].type);
        fprintf(symbolFile,"%d %s %s\n", variables[i].scope_level, variables[i].name, variables[i].type);
    }
}


int main() {
    char in_code[10000] = {0}; 
    read_in("testfile.txt", in_code);
    
    lexical_analysis(in_code);
    parse();
    parse_file("testfile.txt");
	    
    if (error_count){
        output_errors();
    }else{
        output_tokens();
        output_variables();
    }
    
    return 0;
}
