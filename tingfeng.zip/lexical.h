#pragma once
#ifndef LEXICAL_LEXICAL_H
#define LEXICAL_LEXICAL_H

struct CompSymbol{
    int symbol = 0;
    std::string stringContent;
};

enum resType {
    MAINTK, CONSTTK, INTTK, BREAKTK, CONTINUETK, IFTK, ELSETK, WHILETK, GETINTTK,
    PRINTFTK, RETURNTK, VOIDTK, FORTK, CHARTK, GETCHARTK, CHRCON, //match with reword order
    IDENFR, INTCON, STRCON, NOT, AND, OR, PLUS, MINU, MULT, DIV, MOD, LSS, LEQ,
    GRE, GEQ, EQL, NEQ, ASSIGN, SEMICN, COMMA, LPARENT, RPARENT, LBRACK, RBRACK, LBRACE, RBRACE,
    ANNOTATION
};
int getsysmnext(int);
int getsysmcurr();
void lexical_print(bool);
bool isNewLine();
bool isLetter();
bool isDigit();
bool isPlus();
bool isMinu();
bool isMult();
bool isDiv();
bool isMod();
bool isAnd();
bool isOr();
bool isLss();
bool isGre();
bool isExcla();
bool isAssign();
bool isSemicn();
bool isComma();
bool isLparent();
bool isRparent();
bool isLbrack();
bool isRbrack();
bool isLbrace();
bool isRbrace();
bool isDquo();
bool isEOF();
//basic narrating functions
void clearToken();
void catchToken();
void getCh();
void retract();
int isResWord();
//main lexical analysis
int tokenAnalysis();
int output2file();
int output2tm();
int neoLexicalAnalysis(bool);
int getsyms(bool);
#endif //LEXICAL_LEXICAL_H
