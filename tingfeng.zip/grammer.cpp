#include<iostream>
#include<cstring>
#include <string>
#include <fstream>
#include <vector>

#include "grammer.h"
#include "lexical.h"
#include "midcode.h"

#define INTOFFSET 4

using namespace std;

// #define DEBUG_grammer
#define DBEUG_ConstInitVal
#define DEBUG_ConstExp
#define DEBUG_AddExp
#define DEBUG_MulExp
#define DEBUG_isUnaryExp

#ifdef DEBUG_grammer
    #define DEBUG_ConstExp
    #define DEBUG_CompUnit
    #define DEBUG_ConstDecl
    #define DEBUG_Decl
    #define DEBUG_ConstDef
    #define DBEUG_ConstInitVal
#endif

extern int symbol;
extern string neotoken;
extern ofstream outputFile;
extern int symbolListI;
extern int symbolListC;
extern vector<CompSymbol> symbolList;

vector<midCode> midCodeTable;
vector<pair<string, string>> allStringList;    //全局字符串常量 stringName, curString
extern vector<Variable> vTable;    //全局变量表
extern vector<Function> funcvMap;   //函数参数表
vector<pair<string, string>> whileLabel; // loop_begin loop_end
int level = 0;

extern int vAddress;
string curFunction = "";

//区分stmt的几种情况
bool IsExp() {
    for (int i = symbolListI; i < symbolListC; i++) {
        if (symbolList[i].symbol == ASSIGN) {
            return false;
        }
        else if (symbolList[i].symbol == SEMICN) {
            return true;
        }
    }
    return false;
}

int UnitBranch() {
    int i = symbolListI;
    if (symbolList[i].symbol == MAINTK) {
        return 1;
    }
    else if (symbolList[i+1].symbol == LPARENT) {
        return 0;
    }
    else {
        return -1;
    }
}



// 基本类型 BType → 'int' | 'char'
bool isBType(int symbol) {
    return symbol == INTTK || symbol == CHARTK;
}

// VarDecl → BType VarDef { ',' VarDef } ';' // 1.花括号内重复0次 2.花括号内重复
bool isVarDecl(int symbol) {
    return isBType(symbol);
}

bool isConstDecl(int symbol) {
    return symbol == CONSTTK; 
}

// isDecl 的作用是判断当前的 symbol 是否可以是声明 Decl 的起始符号
bool isDecl(int symbol) {
    return isConstDecl(symbol) || isVarDecl(symbol);
}

bool isPrimaryExp() {
    if (symbol == LPARENT) { 
        return 1;
    // } else if (islval()) { 
    //     return 1;
    } else if (symbol == INTCON || symbol == CHRCON) { 
        return 1;
    } else {
        // 错误处理：不合法的 PrimaryExp
        return 0;
    }
}

// Decl → ConstDecl | VarDecl // 覆盖两种声明
bool Decl() {
    if (isConstDecl(symbol)) {
        // 如果是常量声明，调用 ConstDecl()
        #ifdef DEBUG_Decl
            printf("Decl isConstDecl \n");
        #endif
        return ConstDecl();
    } else if (isVarDecl(symbol)) {
        // 如果是变量声明，调用 VarDecl()
        #ifdef DEBUG_Decl
            printf("Decl isVarDecl \n");
        #endif
        return VarDecl();
    }
    return false;  // 不符合声明的语法规则
}

bool isFuncDef(int symbol) {
    // 保存当前符号索引，避免影响后续解析
    int tempSymbolIndex = symbolListI;

    // 检查是否是函数返回类型（int 或 void）
    if (symbol == INTTK || symbol == VOIDTK) {
        getsyms(true);  // 获取下一个符号

        // 检查是否是标识符（函数名）
        if (symbol == IDENFR) {
            getsyms(true);  // 获取下一个符号

            // 检查是否是左括号 '('
            if (symbol == LPARENT) {
                // 如果满足条件，恢复原始状态并返回 true
                symbolListI = tempSymbolIndex;
                symbol = symbolList[symbolListI].symbol;
                neotoken = symbolList[symbolListI].stringContent;
                return true;
            }
        }
    }

    // 如果不符合规则，恢复原始状态并返回 false
    symbolListI = tempSymbolIndex;
    symbol = symbolList[symbolListI].symbol;
    neotoken = symbolList[symbolListI].stringContent;
    return false;
}

// CompUnit → {Decl} {FuncDef} MainFuncDef
bool CompUnit() {
    // 解析 {Decl}
    #ifdef DEBUG_CompUnit
        printf("Start ComUnit\n");
    #endif
    while (isDecl(symbol)) {  // 判断当前 token 是否是声明的起始符号
        if (!Decl()) {
            return false;  // 如果声明解析失败，返回错误
        }
    }
    #ifdef DEBUG_CompUnit
        printf("Decl\n");
    #endif
    // 解析 {FuncDef}
    while (isFuncDef(symbol)) {  // 判断当前 token 是否是函数定义的起始符号
        if (!FuncDef()) {
            return false;  // 如果函数定义解析失败，返回错误
        }
    }    
    #ifdef DEBUG_CompUnit
        printf("FuncDef\n");
    #endif
    // 解析 MainFuncDef
    if (!MainFuncDef()) {
        return false;  // 如果主函数解析失败，返回错误
    }
    #ifdef DEBUG_CompUnit
        printf("MainFuncDef\n");
    #endif

    return true;  // 如果所有部分都解析成功，返回 true
}

//常量声明 ConstDecl → 'const' BType ConstDef { ',' ConstDef } ';'
bool ConstDecl(){
    if (!isConstDecl(symbol)) return false;
    getsyms(true); // const
    #ifdef DEBUG_ConstDecl
        printf("ConstDecl isConstDecl ...\n");
    #endif 
    if (!isBType(symbol)) return false;
    getsyms(true); // BType
    #ifdef DEBUG_ConstDecl
        printf("ConstDecl isBType ...\n");
    #endif 
    // 解析常量定义
    if(!ConstDef()) return false;
    #ifdef DEBUG_ConstDecl
        printf("ConstDecl ConstDef ...\n");
    #endif
    while (symbol == COMMA) {
        #ifdef DEBUG_ConstDecl
            printf("ConstDecl symbol COMMA ...\n");
         #endif 
        getsyms(true); // 跳过逗号
        if (!ConstDef()) return false;
    }
    // 检查是否以分号结束
    if (symbol != SEMICN) return false;
    #ifdef DEBUG_ConstDecl
        printf("SEMICN ...\n");
    #endif 
    getsyms(true); // 跳过分号
    outputFile << "<ConstDecl>" << endl;
    return true;
}

// 常量定义 ConstDef → Ident [ '[' ConstExp ']' ] '=' ConstInitVal 包含普通变量、一维
bool ConstDef() {
    #ifdef DEBUG_ConstDef
        printf("ConstDef start ... \n");
    #endif
    if(symbol != IDENFR) return false;  // 必须是标识符
    string ident = neotoken;
    getsyms(true); // Ident
    int dim = 0;
    vector<int> dimensions;
    while (symbol == LBRACK) {
        getsyms(true); // '['
        dimensions.push_back(stoi(ConstExp()));  // 解析 ConstExp
        if (symbol != RBRACK) return false;  // 检查 ']'
        getsyms(true); // 跳过 ']'
        dim++;
    }
    // 检查是否有 '='
    if (symbol != ASSIGN) return false;
    getsyms(true);  // 跳过 '='
    #ifdef DEBUG_ConstDef
        printf("ConstDef = ... \n");
    #endif
    // 添加变量到符号表
    addOldV(ident, dim, dimensions);
    int variableIndex = vTable.size() - 1;  // 获取刚刚添加的变量索引
    #ifdef DEBUG_ConstDef
        printf("ConstDef addOldV ... \n");
    #endif
    if (!ConstInitVal(variableIndex)) return false;
    #ifdef DEBUG_ConstDef
        printf("ConstDef ConstInitVal ... \n");
    #endif
    // 根据维度生成中间代码
    if (dim == 0) {
        midCodeTable.emplace_back(CONST, vTable[variableIndex].fName);
    }
    else {
        midCodeTable.emplace_back(CONSTARRAY, vTable[variableIndex].fName);
    }

    // 将初始化值拆分并生成赋值代码
    splitAssign(variableIndex, true);
    #ifdef DEBUG_ConstDef
        printf("ConstDef splitAssign ... \n");
    #endif
    outputFile << "<ConstDef>" << endl;
    return true;
}

// ConstInitVal → ConstExp | '{' [ ConstExp { ',' ConstExp } ] '}' | StringConst // 1.常表达式初值 2.一维数组初值
bool ConstInitVal(int variableIndex) {
    // 检查是否是数组形式的初值 '{' ... '}'
    if (symbol == LBRACE) {  
        #ifdef DBEUG_ConstInitVal
            printf("ConstInitVal LBRACE ... \n");
        #endif 
        getsyms(true);  // 跳过 '{'

        // 如果不是空数组，递归解析初值
        if (symbol != RBRACE) {
            ConstInitVal(variableIndex);  // 处理第一个初值
            while (symbol == COMMA) {  // 处理后续的逗号分隔的初值
                getsyms(true);  // 跳过 ','
                ConstInitVal(variableIndex);
            }
        }

        // 确保跳过 '}'，结束数组解析
        if (symbol == RBRACE) {
            getsyms(true);
        } else {
            throw std::logic_error("Missing closing '}' in ConstInitVal");
        }
    } 
    // 如果是字符串常量
    else if (symbol == STRCON) { 
        #ifdef DBEUG_ConstInitVal
            printf("ConstInitVal STRCON ... \n");
        #endif 
        if (neotoken.empty()) {
            throw std::logic_error("Invalid string constant in ConstInitVal");
        }
        vTable[variableIndex].value.push_back(neotoken);  // 保存字符串初值
        getsyms(true);  // 跳过字符串
    } 
    // 如果是常量表达式
    else {
        #ifdef DBEUG_ConstInitVal
            printf("ConstInitVal ConstExp ... \n");
        #endif 
        string constValue = ConstExp();
        if (constValue.empty()) {
            throw std::logic_error("Invalid constant expression in ConstInitVal");
        }
        vTable[variableIndex].value.push_back(constValue);  // 保存常量初值
    }

    // 输出语法结构
    outputFile << "<ConstInitVal>" << endl;
    return true;
}

//变量声明 VarDecl → BType VarDef { ',' VarDef } ';'
bool VarDecl() {
    if(!isBType(symbol)) return false;
    getsyms(true); // BType
    VarDef();
    while (symbol == COMMA) {
        getsyms(true);
        VarDef();
    }
    getsyms(true);
    outputFile << "<VarDecl>" << endl;
    return true;
}

//  VarDef → Ident [ '[' ConstExp ']' ] | Ident [ '[' ConstExp ']' ] '=' InitVal // 包含普通常量、一维数组定义
bool VarDef() {
    vector<int>d; d.resize(3);
    string ident = neotoken;

    getsyms(true); // Ident
    int dim = 0;
    while (symbol == LBRACK) {
        dim += 1;
        getsyms(true); // '['
        d[dim-1] = stoi(ConstExp());
        getsyms(true); // ']'
    }

    addOldV(ident, dim, d);
    int variableIndex = vTable.size()-1;
    if (dim == 0) {
        midCodeTable.emplace_back(VAR, vTable[variableIndex].fName);
    }
    else {
        midCodeTable.emplace_back(ARRAY, vTable[variableIndex].fName);
    }
    if (symbol == ASSIGN) {
        getsyms(true); // '='
        InitVal(variableIndex);
        splitAssign(variableIndex, false);
    }
    outputFile << "<VarDef>" << endl;
    return true;
}

//变量初值 InitVal → Exp | '{' [ InitVal { ',' InitVal } ] '}'
bool InitVal(int variableIndex) {
    if (symbol != LBRACE) {
        string exp = Exp();
        vTable[variableIndex].value.push_back(exp);
    }
    else {
        getsyms(true);
        if (symbol != RBRACE) {
            InitVal(variableIndex);
            while (symbol == COMMA) {
                getsyms(true);
                InitVal(variableIndex);
            }
        }
        getsyms(true);
    }
    outputFile << "<InitVal>" << endl;
    return true;
}

//函数定义 FuncDef → FuncType Ident '(' [FuncFParams] ')' Block
bool FuncDef() {
    bool isFuncFollow = true;
    vAddress = 0;
    level += 1;

    Function f;
    f.type = FuncType();
    string ident = neotoken;
    f.ident = ident;
    curFunction = ident;
    vector<Variable> params;
    f.params = params;
    funcvMap.push_back(f);
    midCodeTable.emplace_back(FUNC, f.type == 1 ? "int" : "void", ident);
    getsyms(true);
    getsyms(true);
    if (symbol != RPARENT) {
        FuncFParams(ident);
    }

    getsyms(true);
    Block(isFuncFollow);
    outputFile << "<FuncDef>" << endl;

    level -= 1;
    if (midCodeTable[midCodeTable.size()-1].op != RET) {
        midCodeTable.emplace_back(RET);
    }
    curFunction = "";
    funcvMap[funcvMap.size()-1].length = vAddress + 8;
    return true;
}

//主函数定义 MainFuncDef → 'int' 'main' '(' ')' Block
bool MainFuncDef() {
    midCodeTable.emplace_back(FUNC, "int", "main");
    bool isFuncFollow = true;
    level += 1;
    vAddress = 0;
    curFunction = "main";

    for (int i = 0; i < 3; i++) {
        getsyms(true);
    }
    getsyms(true);
    Block(isFuncFollow);
    outputFile << "<MainFuncDef>" << endl;

    midCodeTable.emplace_back(EXIT);
    level -= 1;
    curFunction = "";

    vector<Variable> params;
    Function function;
    function.ident = "main";
    function.type = 1;
    function.length = vAddress + 8;
    function.params = params;
    funcvMap.push_back(function);
    return true;
}

//函数类型 FuncType → 'void' | 'int'
bool FuncType() {
    bool isInt = (symbol == INTTK);
    getsyms(true);
    outputFile << "<FuncType>" << endl;
    return isInt;
}

//函数形参表 FuncFParams → FuncFParam { ',' FuncFParam }
bool FuncFParams(string ident) {
    FuncFParam(ident);
    while (symbol == COMMA) {
        getsyms(true);
        FuncFParam(ident);
    }
    outputFile << "<FuncFParams>" << endl;
    return true;
}

//函数形参 FuncFParam → BType Ident ['[' ']' { '[' ConstExp ']' }]
bool FuncFParam(string ident) {
    getsyms(true);
    int dim = 0;
    vector<int> d; d.resize(3);
    string varident = neotoken;
    getsyms(true);
    if (symbol == LBRACK) {
        dim += 1;
        d[dim-1] = 0;
        getsyms(true);
        getsyms(true);
        while (symbol == LBRACK) {
            dim += 1;
            getsyms(true);
            d[dim-1] = stoi(ConstExp());
            getsyms(true);
        }
    }
    addOldV(varident, dim, d);
    Variable &v = vTable[vTable.size()-1];
    funcvMap[funcvMap.size()-1].params.push_back(v);
    midCodeTable.emplace_back(PARAM, v.fName);
   outputFile << "<FuncFParam>" << endl;
//    if (dim == 0) {
//        midCodeTable.emplace_back(VAR, varident);
//    }
//    else {
//        midCodeTable.emplace_back(ARRAY, varident);
//    }
    return true;
}

//语句块项 BlockItem → Decl | Stmt
//语句块 Block → '{' { BlockItem } '}'
bool Block(bool isFuncFollow) {
    if (!isFuncFollow) {
        level += 1;
    }

    getsyms(true);
    while(true) {
        if (symbol == RBRACE) {
            break;
        }
        if (ConstDecl()) {}
        else if (symbol == INTTK) {
            VarDecl();
        }
        else {
            Stmt();
        }
    }
    getsyms(true);
    outputFile << "<Block>" << endl;

    checkvTable();
    if(!isFuncFollow) {
        level -= 1;
    }
    return true;
}


/*语句 Stmt →
/ LVal '=' Exp ';'
| LVal '=' 'getint''('')'';'
| [Exp] ';' //有?Exp两种情况

| Block
| 'if' '(' Cond ')' Stmt [ 'else' Stmt ] // 1.有else 2.?else
| 'while' '(' Cond ')' Stmt
| 'break' ';' | 'continue' ';'
| 'return' [Exp] ';' // 1.有Exp 2.?Exp
| 'printf''('FormatString{','Exp}')'';' // 1.有Exp 2.?Exp
*/
bool Stmt() {
    switch (symbol) {
        case LBRACE:{
            Block(false);
            break;
        }
        //'if' '(' Cond ')' Stmt [ 'else' Stmt ] // 1.有else 2.?else
        case IFTK: {
            string else_label = getLabel();
            string if_end = getLabel();
            getsyms(true);
            getsyms(true);
            string op = Cond();
            getsyms(true);
            midCodeTable.emplace_back(BZ, else_label, op);
            Stmt();
            if (symbol == ELSETK) {
                midCodeTable.emplace_back(GOTO, if_end);
            }
            midCodeTable.emplace_back(LABEL, else_label);
            if (symbol == ELSETK) {
                getsyms(true);
                Stmt();
                midCodeTable.emplace_back(LABEL, if_end);
            }
            break;
        }

        //'while' '(' Cond ')' Stmt
//        goto label2
//        label1:
//        <语句>
//        label2: (begin)
//        if <条件> goto label1
//        label3: (end)
        case WHILETK:{
//          print();
            string loop_begin = getLabel();
            string loop_end = getLabel();
            string loop_label1 = getLabel();
//          midCodeTable.emplace_back(LABEL, loop_begin, "loop_begin");
            whileLabel.emplace_back(make_pair(loop_begin, loop_end));
            midCodeTable.emplace_back(GOTO, loop_begin);
            midCodeTable.emplace_back(LABEL, loop_label1);
            getsyms(true);
            getsyms(true);
            string op = Cond();//会产生<cond>midcodes

            //<cond>相关代码
            vector<midCode> insMidCode;
            auto iter = midCodeTable.end() - 1;
            while (iter->z != loop_label1) {
                insMidCode.insert(insMidCode.begin(), *iter);
                iter = midCodeTable.erase(iter);
                iter --;
            }

//          midCodeTable.emplace_back(BZ, loop_end, op);
//          print();
            getsyms(true);
            Stmt();
            whileLabel.pop_back();
            midCodeTable.emplace_back(LABEL, loop_begin);

            //<cond>相关代码
            midCodeTable.insert(midCodeTable.end(), insMidCode.begin(), insMidCode.end());

            midCodeTable.emplace_back(BNZ, loop_label1, op);
            midCodeTable.emplace_back(LABEL, loop_end);
//          midCodeTable.emplace_back(GOTO, loop_begin);
//          midCodeTable.emplace_back(LABEL, loop_end, "loop_end");
            break;
        }

        case BREAKTK: {
            getsyms(true);
            getsyms(true);
            midCodeTable.emplace_back(GOTO, whileLabel[whileLabel.size()-1].second);
            break;
        }

        case CONTINUETK: {
            getsyms(true);
            getsyms(true);
            midCodeTable.emplace_back(GOTO, whileLabel[whileLabel.size()-1].first, "continue");
            break;
        }

        //'return' [Exp] ';' // 1.有Exp 2.?Exp
        case RETURNTK:{
            getsyms(true);
            if (symbol == SEMICN) {
                getsyms(true);
                midCodeTable.emplace_back(RET);
                break;
            }
            string ret = Exp();
            getsyms(true);
            midCodeTable.emplace_back(RET, ret);
            break;

        }

        //' printf''('FormatString{','Exp}')'';' // 1.有Exp 2.?Exp
        case PRINTFTK: {
            vector<int> consequence;
            vector<pair<string, string>> stringList;
            getsyms(true);
            getsyms(true);
            string formatstring = neotoken;
            string curString;
            //把字符串分开并记录顺序
            for (int i=0; i<formatstring.size(); i++) {
                if ((formatstring[i] == '%') && (formatstring[i+1] == 'd')) {
                    if (!curString.empty()) {
                        string stringName = getString();
                        allStringList.emplace_back(stringName, curString);
                        stringList.emplace_back(stringName, curString);
                        consequence.push_back(0);
                    }
                    consequence.push_back(1);
                    i ++;
                    curString = "";
                }
                else {
                    curString += formatstring[i];
                }
            }
            if (!curString.empty()) {
                string stringName = getString();
                allStringList.emplace_back(stringName, curString);
                stringList.emplace_back(stringName, curString);
                consequence.push_back(0);
            }
            getsyms(true);
            vector<string> varList;
            while (symbol == COMMA) {
                getsyms(true);
                varList.push_back(Exp());
            }
            getsyms(true);

            for (int i = 0; i < consequence.size(); i++) {
                if (consequence[i] == 1) {
                    midCodeTable.emplace_back(PRINTD, varList[0]);
                    varList.erase(varList.begin());
                }
                else if (consequence[i] == 0) {
                    midCodeTable.emplace_back(PRINTS, stringList[0].first, stringList[0].second);
                    stringList.erase(stringList.begin());
                }
            }
            break;
        }

        case SEMICN:
            getsyms(true);
            break;

//    | LVal '=' Exp ';'
//    | LVal '=' 'getint''('')'';'
//    | [Exp] ';' //有?Exp两种情况
        case IDENFR: {
            if (IsExp()) {
                Exp();
                getsyms(true);
            }
            else {
                string lval;
                lval = LVal(false);
                string offset = isContainOffset(lval);
                getsyms(true);
                if (symbol == GETINTTK) {
                    if (offset.size() == 0) {
                        midCodeTable.emplace_back(SCAN, lval);
                    }
                    else {
                        string newV = addInsV();
                        midCodeTable.emplace_back(SCAN, newV);
                        midCodeTable.emplace_back(PUTARRAY, getVarWithoutOffset(lval), offset, newV);
                    }
                    for (int i = 0; i < 3; i++) {
                        getsyms(true);
                    }
                    getsyms(true);
                }
                else {
                    string rval = Exp();
                    if (offset.size() == 0) {
                        midCodeTable.emplace_back(ASSIGNOP, lval, rval);
                    }
                    else {
                        midCodeTable.emplace_back(PUTARRAY, getVarWithoutOffset(lval), offset, rval);
                    }
                    getsyms(true);
                }
            }
            break;
        }

        default:
            Exp();
            getsyms(true);
    }
    outputFile << "<Stmt>" << endl;
    return true;
}

//表达式 Exp → AddExp 注：SysY 表达式是int 型表达式
string Exp() {
    string neoVar = AddExp();
    outputFile << "<Exp>" << endl;
    return neoVar;
}

//条件表达式 Cond → LOrExp
string Cond() {
    string neoVar = LOrExp();
    outputFile << "<Cond>" << endl;
    return neoVar;
}


//check初始化值/indexs是不是全是数字
bool isAllNumber(vector<string> list) {
    for (int i = 0; i < list.size(); i ++) {
        if (!isNumber(list[i])) {
            return false;
        }
    }
    return true;
}

//对于right 为ident / number / ident[offset]
string LValGetValue(string ident, vector<string> indexs) {
    //找到对应变量
    Variable variable;
    for (int i = vTable.size()-1; i >= 0; i--) {
        if ((vTable[i].rName == ident) && (vTable[i].valid)) {
            variable = vTable[i];
            break;
        }
    }
    //精确到了值
    if (variable.dimCount == indexs.size()) {
        //能拿出来一个数
        if ((!variable.value.empty())&&(isAllNumber(indexs))&&(isAllNumber(variable.value))) {
            switch (indexs.size()) {
                case 0:{
                    return variable.value[0];
                    break;
                }
                case 1:{
                    return variable.value[stoi(indexs[0])];
                    break;
                }
                case 2:{
                    int offset = stoi(indexs[0]) * variable.dim[1] + stoi(indexs[1]);
                    return variable.value[offset];
                    break;
                }
            }
        }
        //只能返回一个变量
        else {
            switch (indexs.size()) {
                case 0:
                    return variable.fName;
                    break;
                case 1: {
                    string neoV = addInsV();
                    midCodeTable.emplace_back(GETARRAY, neoV, variable.fName, indexs[0]);
                    return neoV;
                    break;
                }
                case 2: {
                    string neoV = merge(MULTOP, indexs[0], to_string(variable.dim[1]));
                    string neoVV = merge(PLUSOP, neoV, indexs[1]);
                    string neoVVV = addInsV();
                    midCodeTable.emplace_back(GETARRAY, neoVVV, variable.fName, neoVV);
                    return neoVVV;
                    break;
                }
            }
        }
    }
    //要了个数组（函数实参）
    else if (variable.dimCount > indexs.size()){
        if (indexs.size() == 0) {
            return variable.fName + "[" + "0" + "]";
        }
        else if ((indexs.size() == 1) && (variable.dimCount == 2)) {
            string neoV = merge(MULTOP, indexs[0], to_string(variable.dim[1]));
            return variable.fName + "[" + neoV + "]";
        }
    }
}

//对于left 为 ident[offset]
string LValGetLeft(string ident, vector<string> indexs) {
    for (int i = vTable.size() - 1; i >= 0; i--) {
        if ((vTable[i].rName == ident) && (vTable[i].valid)) {
            if (indexs.empty()) {
                return vTable[i].fName;
            }
            else if (indexs.size() == 1) {
                return vTable[i].fName + "[" + indexs[0] + "]";
            }
            else if (indexs.size() == 2) {
                string neoV = merge(MULTOP, indexs[0], to_string(vTable[i].dim[1]));
                string neoVV = merge(PLUSOP, neoV, indexs[1]);
                return vTable[i].fName + "[" + neoVV + "]";
            }
        }
    }
}
//左值表达式 LVal → Ident {'[' Exp ']'}
//对于left 为 <ident, offset>
//对于right 为<variable, NONE> / <number, NONE> / <ident, offset>
string LVal(bool isGet) {
//  print();
    string re;
    string ident = neotoken;
    vector<string> indexs;
    getsyms(true);
    while (true) {
        if (symbol == LBRACK) {
            getsyms(true);
            string index = Exp();
            indexs.push_back(index);
            getsyms(true);
        } else {
            break;
        }
    }
    if (isGet) {
        re = LValGetValue(ident, indexs);
    } else {
        re = LValGetLeft(ident, indexs);
    }
    outputFile << "<LVal>" << endl;
    return re;
}

//基本表达式 PrimaryExp → '(' Exp ')' | LVal | Number // 三种情况均需覆盖
string PrimaryExp() {
    string neoVar;
    if (symbol == LPARENT) {
        getsyms(true);
        neoVar = Exp();
        getsyms(true);
    }
    else if (symbol != INTCON) {
        neoVar = LVal(true);
    }
    else if (symbol == INTCON) {
        neoVar = Number();
    }
    outputFile << "<PrimaryExp>" << endl;
    return neoVar;
}

//数值 Number → IntConst // 存在即可
string Number(){
    if (symbol == INTCON) {
        string neoVar = neotoken;
        getsyms(true);
        outputFile << "<Number>" << endl;
        return neoVar;
    }
}

//?元表达式 UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp // 存在即可
string UnaryExp() {
    printf("UnaryExp start ...\n");
    string neoVar;
    if (symbol == PLUS || symbol == MINU || symbol == NOT) {
        string neoOp = UnaryOp();
        if (neoOp == "+") {
            neoVar = UnaryExp();
        }
        else if (neoOp == "-") {
            neoVar = merge(MINUOP, "0", UnaryExp());
        }
        else if (neoOp == "!") {
            neoVar = merge(NOTOP, UnaryExp(), "");
        }
    }
    else if (isPrimaryExp()) {
        neoVar = PrimaryExp();
    }
    else if (symbol == IDENFR && getsysmcurr() == LPARENT) {
        getsyms(true);
        if (symbol == LPARENT) {
            string ident = neotoken;
            if (symbol != RPARENT) {
                FuncRParams(ident);
                //  add_error(token_forms[current_token - 1].line_count, 'j', "缺少右小括号 ')'");
            }
            getsyms(true);
            midCodeTable.emplace_back(CALL, ident);
            for (int i = funcvMap.size()-1; i >= 0 ; i--) {
                if (funcvMap[i].ident == ident) {
                    if (funcvMap[i].type == 1) {
                        neoVar = addInsV();
                        midCodeTable.emplace_back(RETVALUE, neoVar, "RET");
                    }
                }
            }
        }
        else {
            neoVar = PrimaryExp();
        }
    }
    outputFile << "<UnaryExp>" << endl;
    return neoVar;
}

//单?运算符 UnaryOp → '+' | '?' | '!' 注：'!'仅出现在条件表达式中 // 三种均需覆盖
string UnaryOp() {
    if (symbol == PLUS || symbol == MINU || symbol == NOT) {
        string neoOp;
        switch (symbol) {
            case PLUS:
                neoOp = "+";
                break;
            case MINU:
                neoOp = "-";
                break;
            case NOT:
                neoOp = "!";
                break;
        }
        getsyms(true);
        outputFile << "<UnaryOp>" << endl;
        return neoOp;
    }
    return "";
}

// 将实参 传值/传指针
// Params: ident函数名, dim第几个, neoVar实参名
void funcParamPush(string ident, int dim, string neoVar) {
    string offset = isContainOffset(neoVar);
    //传值
    if (offset.size() == 0) {
        midCodeTable.emplace_back(PUSH, neoVar, to_string(dim));
    }
    //传地址
    else {
        string ident = getVarWithoutOffset(neoVar);
        midCodeTable.emplace_back(PUSHADDR, ident, offset, to_string(dim));
    }
}

//函数实参表 FuncRParams → Exp { ',' Exp }
bool FuncRParams(string ident) {
    string neoVar;
    vector<string> params;
    neoVar = Exp();
    params.push_back(neoVar);
    while (symbol == COMMA) {
        getsyms(true);
        neoVar = Exp();
        params.push_back(neoVar);
    }
    for (int i = 0; i < params.size(); i++) {
        funcParamPush(ident, i, params[i]);
    }
    outputFile << "<FuncRParams>" << endl;
    return true;
}

bool isUnaryExp() {
    #ifdef DEBUG_isUnaryExp
        printf("isUnaryExp start ...\n");
    #endif
    if (isPrimaryExp()) {  
        return 1;
    } else if (symbol == IDENFR && getsysmcurr() == LPARENT) {
            return 1;
    } else if (symbol == PLUS || symbol == MINU || symbol == NOT) {  // 检查是否是 UnaryOp
        return 1;
    }
    return 0;  
}

//乘除模表达式 MulExp → UnaryExp | MulExp ('*' | '/' | '%') UnaryExp
string MulExp() {
    #ifdef DEBUG_MulExp
        printf("MulExp start ....\n");
    #endif
    string neoVar = "";
    if(isUnaryExp()){
        #ifdef DEBUG_MulExp
            printf("MulExp UnaryExp enter ...\n");
        #endif
        neoVar = UnaryExp();
    }
    #ifdef DEBUG_MulExp
        printf("MulExp enter UnaryExp ...\n");
    #endif
    while (symbol == MULT || symbol == DIV || symbol == MOD) {
        #ifdef DEBUG_MulExp
            printf("MulExp enter while ...\n");
        #endif
        outputFile << "<MulExp>" << endl;
        operation op;
        if (symbol == MULT) {
            op = MULTOP;
        } else if (symbol == DIV) {
            op = DIVOP;
        } else if (symbol == MOD) {
            op = MODOP;
        }
        getsyms(true);
        neoVar = merge(op, neoVar, UnaryExp());
    }
    #ifdef DEBUG_MulExp
        printf("MulExp end ...\n");
    #endif
    outputFile << "<MulExp>" << endl;
    return neoVar;
}

/* 
    加减表达式 AddExp → MulExp | AddExp ('+' | '−') MulExp 
    1. 解析第一个 MulExp
    2. 处理 '+' 和 '-' 运算符，并递归解析 MulExp
*/
string AddExp() {
    #ifdef DEBUG_AddExp
        printf("AddExp start ... \n");
    #endif
    // 初始化结果变量
    string neoVar = MulExp();  // 解析第一个 MulExp
    // 循环解析 '+' 或 '-' 后的 MulExp
    #ifdef DEBUG_AddExp
        printf("AddExp enter MulExp ... \n");
    #endif
    while (symbol == PLUS || symbol == MINU) {
        // 打印 <AddExp> 的语法标签
        outputFile << "<AddExp>" << endl;
        // 保存当前操作符
        operation op = (symbol == PLUS) ? PLUSOP : MINUOP;
        // 获取下一个符号
        getsyms(true);
        // 解析下一个 MulExp，并合并操作
        neoVar = merge(op, neoVar, MulExp());
    }
    #ifdef DEBUG_AddExp
        printf("AddExp end ... \n");
    #endif
    // 打印 <AddExp> 的语法标签
    outputFile << "<AddExp>" << endl;
    return neoVar;  // 返回最终的合并结果
}


//关系表达式 RelExp → AddExp | RelExp ('<' | '>' | '<=' | '>=') AddExp
string RelExp() {
    string neoVar = AddExp();
    outputFile << "<RelExp>" << endl;
    while (symbol == LSS || symbol == GRE || symbol == LEQ || symbol == GEQ) {
        if (symbol == LSS) {
            getsyms(true);
            neoVar = merge(LSSOP, neoVar, AddExp());
        }
        else if (symbol == GRE) {
            getsyms(true);
            neoVar = merge(GREOP, neoVar, AddExp());
        }
        else if (symbol == LEQ) {
            getsyms(true);
            neoVar = merge(LEQOP, neoVar, AddExp());
        }
        else if (symbol == GEQ) {
            getsyms(true);
            neoVar = merge(GEQOP, neoVar, AddExp());
        }
        outputFile << "<RelExp>" << endl;
    }
    return neoVar;
}

//相等性表达式 EqExp → RelExp | EqExp ('==' | '!=') RelExp
string EqExp() {
    string neoVar = RelExp();
    outputFile << "<EqExp>" << endl;
    while (symbol == EQL || symbol == NEQ) {
        if (symbol == EQL) {
            getsyms(true);
            neoVar = merge(EQLOP, neoVar, RelExp());
        }
        else if (symbol == NEQ) {
            getsyms(true);
            neoVar = merge(NEQOP, neoVar, RelExp());
        }
        outputFile << "<EqExp>" << endl;
    }
    return neoVar;
}

//逻辑与表达式 LAndExp → EqExp | LAndExp '&&' EqExp // 1.EqExp 2.&& 均需覆盖
bool LAndExp(string andEndLabel) {
    bool andFlag = false;
    string eqExp = EqExp();
    outputFile << "<LAndExp>" << endl;
    midCodeTable.emplace_back(BZ, andEndLabel, eqExp);
    while (symbol == AND) {
        andFlag = true;
        getsyms(true);
        eqExp = EqExp();
        midCodeTable.emplace_back(BZ, andEndLabel, eqExp);
        outputFile << "<LAndExp>" << endl;
    }
    return andFlag;
}

//逻辑或表达式 LOrExp → LAndExp | LOrExp '||' LAndExp // 1.LAndExp 2.|| 均需覆盖
string LOrExp() {
    bool andFlag = false;
    bool orFlag = false;
    string neoVar = addNewV(); //此处的neoVar会被使用三次
    string andEndLabel = getLabel();
    string orEndLabel = getLabel();
    andFlag = LAndExp(andEndLabel);
    midCodeTable.emplace_back(ASSIGNOP, neoVar, "1");
    midCodeTable.emplace_back(GOTO, orEndLabel);
    midCodeTable.emplace_back(LABEL, andEndLabel);
    midCodeTable.emplace_back(ASSIGNOP, neoVar, "0");
    outputFile << "<LOrExp>" << endl;
    while (symbol == OR) {
        orFlag = true;
        getsyms(true);
        andEndLabel = getLabel();
        andFlag = LAndExp(andEndLabel) || andFlag;
        midCodeTable.emplace_back(ASSIGNOP, neoVar, "1");
        midCodeTable.emplace_back(GOTO, orEndLabel);
        midCodeTable.emplace_back(LABEL, andEndLabel);
        midCodeTable.emplace_back(ASSIGNOP, neoVar, "0");
        outputFile << "<LOrExp>" << endl;
    }
    midCodeTable.emplace_back(LABEL, orEndLabel);
    if (!andFlag && !orFlag) {
        for (int i = 0; i < 5; i++) {
            midCodeTable.pop_back();
        }
        neoVar = midCodeTable[midCodeTable.size()-1].x;
        midCodeTable.pop_back();
    }
    return neoVar;
}

// 常量表达式 ConstExp → AddExp 注：使用的 Ident 必须是常量
string ConstExp() {
    #ifdef DEBUG_ConstExp
        printf("ConstExp enter ...\n");
    #endif 
    string neoVar;
    neoVar = AddExp();
    if(neoVar.empty()) {
        throw std::logic_error("ConstExp generated empty value");
    }
    #ifdef DEBUG_ConstExp
        printf("ConstExp end ...\n");
    #endif 
    outputFile << "<ConstExp>" << endl;
    return neoVar;
}

//main function
bool Gprocess(){
    return CompUnit();
}