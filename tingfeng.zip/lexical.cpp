#include<iostream>
#include<cstring>
#include <string>
#include <fstream>
#include <vector>
#include "lexical.h"

using namespace std;

// #define DEBUG_lexical
#ifdef DEBUG_lexical
    #define DEBUG_getsyms
#endif

int resWordCount = 15;
int symbolListI = 0;
int symbolListC = 0;
int tokenI = 0;
int symbol;
int indexs = 0;
int line = 1;

char ch;
char token[1000000000];
char resWord[21][10] {
        "main", "const", "int", "break", "continue", "if", "else", "while", "getint",
        "printf", "return", "void", "for", "char", "getchar"// match with resType order
};

string neotoken;
string fileContent;
extern ofstream outputFile;

vector<CompSymbol> symbolList;

//basic item recognition
bool isBlank() {
    return (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r' || ch == '\f' || ch == '\v');
}
bool isNewLine() {
    return (ch == '\n');
}
bool isLetter(){
    return ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch == '_'));
}
bool isDigit(){
    return (ch >= '0' && ch <= '9');
}
bool isPlus(){
    return (ch == '+');
}
bool isMinu(){
    return (ch == '-');
}
bool isMult(){
    return (ch == '*');
}
bool isDiv(){
    return (ch == '/');
}
bool isMod(){
    return (ch == '%');
}
bool isAnd(){
    return (ch == '&');
}
bool isOr(){
    return (ch == '|');
}
bool isLss(){
    return (ch == '<');
}
bool isGre(){
    return (ch == '>');
}
bool isExcla(){
    return (ch == '!');
}
bool isAssign(){
    return (ch == '=');
}
bool isSemicn(){
    return (ch == ';');
}
bool isComma(){
    return (ch == ',');
}
bool isLparent(){
    return (ch == '(');
}
bool isRparent(){
    return (ch == ')');
}
bool isLbrack(){
    return (ch == '[');
}
bool isRbrack(){
    return (ch == ']');
}
bool isLbrace(){
    return (ch == '{');
}
bool isRbrace(){
    return (ch == '}');
}
bool isDquo(){
    return (ch == '\"');
}
bool isEOF(){
    return (indexs >= fileContent.size());
}

//basic narrating functions
void clearToken(){
    tokenI = 0;
}
void catchToken() {
    if (tokenI < sizeof(token) - 1) { // Avoid overflow
        token[tokenI++] = ch;
    } else {
        cerr << "Error: Token buffer overflow at line " << line << endl;
    }
}

void getCh(){
    ch = fileContent[indexs++];
    if (isNewLine()) {
        line++;
    }
}
void retract(){
    if (isNewLine()) {
        line--;
    }
    indexs--;
}
int isResWord(){
    for (int i = 0; i < resWordCount; i++) {
        if (strcmp(resWord[i], token) == 0) {
            return i;
        }
    }
    return -1;
}

//main lexical analysis
int tokenAnalysis() {
    clearToken();
    getCh();
    while (isBlank()) {
        getCh();
    }
    if (isEOF()) {
        return -1;
    }
    if (isLetter()) {
        while (isLetter() || isDigit()) {
            catchToken();
            getCh();
        }
        retract();
        token[tokenI] = '\0';
        int resValue = isResWord();
        if (resValue == -1) {
            symbol = IDENFR;
        }
        else {
            symbol = (resType)resValue;
        }
        return 1;
    }
    else if (isDigit()) {
        while (isDigit()) {
            catchToken();
            getCh();
        }
        retract();
        token[tokenI] = '\0';
        symbol = INTCON;
        return 1;
    }
    else if (isDquo()) {
        getCh();
        while (!isDquo()) {
            catchToken();
            getCh();
        }
        symbol = STRCON;
        token[tokenI] = '\0';
        return 1;
    }
    else if (isAnd()) {
        getCh();
        if (isAnd()) {
            symbol = AND;
            return 1;
        }
        else {
            return -1;
        }
    }
    else if (isOr()) {
        getCh();
        if (isOr()) {
            symbol = OR;
            return 1;
        }
        else {
            return -1;
        }
    }
    else if (isPlus()) {
        symbol = PLUS;
        return 1;
    }
    else if (isMinu()) {
        symbol = MINU;
        return 1;
    }
    else if (isMult()) {
        symbol = MULT;
        return 1;
    }
    else if (isDiv()) {
        getCh();
        if (isDiv()) {  // //
            while (!isNewLine()) {
                getCh();
            }
            symbol = ANNOTATION;
            return 1;
        }
        else if (isMult()) {    // /*
            while(true) {
                getCh();
                if (isMult()) {
                    getCh();
                    if (isDiv()){
                        symbol = ANNOTATION;
                        break;
                    }
                    retract();
                }
            }
            return 1;
        }
        retract();
        symbol = DIV;
        return 1;
    }
    else if (isMod()) {
        symbol = MOD;
        return 1;
    }
    else if (isLss()) {
        getCh();
        if (isAssign()) {
            symbol = LEQ;
        }
        else {
            symbol = LSS;
            retract();
        }
        return 1;
    }
    else if (isGre()) {
        getCh();
        if (isAssign()) {
            symbol = GEQ;
        }
        else {
            symbol = GRE;
            retract();
        }
        return 1;
    }
    else if (isExcla()) {
        getCh();
        if (isAssign()) {
            symbol = NEQ;
        }
        else {
            retract();
            symbol = NOT;
        }
        return 1;
    }
    else if (isAssign()) {
        getCh();
        if (isAssign()) {
            symbol = EQL;
        }
        else {
            symbol = ASSIGN;
            retract();
        }
        return 1;
    }
    else if (isSemicn()) {
        symbol = SEMICN;
        return 1;
    }
    else if (isComma()) {
        symbol = COMMA;
        return 1;
    }
    else if (isLparent()) {
        symbol = LPARENT;
        return 1;
    }
    else if (isRparent()) {
        symbol = RPARENT;
        return 1;
    }
    else if (isLbrack()) {
        symbol = LBRACK;
        return 1;
    }
    else if (isRbrack()) {
        symbol = RBRACK;
        return 1;
    }
    else if (isLbrace()) {
        symbol = LBRACE;
        return 1;
    }
    else if (isRbrace()) {
        symbol = RBRACE;
        return 1;
    }
    else if (ch == '\'') { // Handle character literals

        getCh(); // Get the character inside the single quotes
        if (ch == '\\') { // Check for escape sequences
            catchToken();
            getCh(); // Consume the character after '\'
            if (ch == 'n' || ch == 't' || ch == '\\' || ch == '\'' || ch == 'r' || ch == '0') {
                catchToken(); // Store the valid escape sequence
            } else {
                cerr << "Error: Invalid escape sequence '\\"
                    << ch << "' at line " << line << endl;
                return -1;
            }
        } else if (ch == '\'' || isLetter() || isDigit() || isPlus() || isMinu() || isMult() || isDiv()) {
            if (ch == '\'') { // If the character is a single quote, it is invalid
                cerr << "Error: Invalid character literal (extra single quote) at line " << line << endl;
                return -1;
            }
            catchToken(); // Store the character
        } else {
            catchToken(); // Store the character
        }
        getCh(); // Consume the closing single quote
        if (ch != '\'') { // Ensure it’s properly closed
            cerr << "Error: Missing closing single quote at line " << line << endl;
            return -1;
        }
        symbol = CHRCON; // Set token type
        token[tokenI] = '\0'; // Null-terminate the token
        return 1;
    }
    else {
        return -1;
    }
}

int output2file() {
   switch (symbol) {
        case GETCHARTK:
            outputFile << "GETCHARTK " << neotoken << endl;
            break;
        case CHRCON:
            outputFile << "CHRCON '" << neotoken << "'" << endl;
            break;
        case CHARTK:
            outputFile << "CHARTK " << neotoken << endl;
            break;
        case FORTK:
            outputFile << "FORTK " << neotoken << endl;
            break;
        case IDENFR:
            outputFile << "IDENFR " << neotoken << endl;
            break;
        case INTCON:
            outputFile << "INTCON " << neotoken << endl;
            break;
        case STRCON:
            outputFile << "STRCON " << "\"" << neotoken << "\"" << endl;
            break;
        case MAINTK:
            outputFile << "MAINTK main" << endl;
            break;
        case CONSTTK:
            outputFile << "CONSTTK const" << endl;
            break;
        case INTTK:
            outputFile << "INTTK int" << endl;
            break;
        case BREAKTK:
            outputFile << "BREAKTK break" << endl;
            break;
        case CONTINUETK:
            outputFile << "CONTINUETK continue" << endl;
            break;
        case IFTK:
            outputFile << "IFTK if" << endl;
            break;
        case ELSETK:
            outputFile << "ELSETK else" << endl;
            break;
        case NOT:
            outputFile << "NOT !" << endl;
            break;
        case AND:
            outputFile << "AND &&" << endl;
            break;
        case OR:
            outputFile << "OR ||" << endl;
            break;
        case WHILETK:
            outputFile << "WHILETK while" << endl;
            break;
        case GETINTTK:
            outputFile << "GETINTTK getint" << endl;
            break;
        case PRINTFTK:
            outputFile << "PRINTFTK printf" << endl;
            break;
        case RETURNTK:
            outputFile << "RETURNTK return" << endl;
            break;
        case PLUS:
            outputFile << "PLUS +" << endl;
            break;
        case MINU:
            outputFile << "MINU -" << endl;
            break;
        case VOIDTK:
            outputFile << "VOIDTK void" << endl;
            break;
        case MULT:
            outputFile << "MULT *" << endl;
            break;
        case DIV:
            outputFile << "DIV /" << endl;
            break;
        case MOD:
            outputFile << "MOD %" << endl;
            break;
        case LSS:
            outputFile << "LSS <" << endl;
            break;
        case LEQ:
            outputFile << "LEQ <=" << endl;
            break;
        case GRE:
            outputFile << "GRE >" << endl;
            break;
        case GEQ:
            outputFile << "GEQ >=" << endl;
            break;
        case EQL:
            outputFile << "EQL ==" << endl;
            break;
        case NEQ:
            outputFile << "NEQ !=" << endl;
            break;
        case ASSIGN:
            outputFile << "ASSIGN =" << endl;
            break;
        case SEMICN:
            outputFile << "SEMICN ;" << endl;
            break;
        case COMMA:
            outputFile << "COMMA ," << endl;
            break;
        case LPARENT:
            outputFile << "LPARENT (" << endl;
            break;
        case RPARENT:
            outputFile << "RPARENT )" << endl;
            break;
        case LBRACK:
            outputFile << "LBRACK [" << endl;
            break;
        case RBRACK:
            outputFile << "RBRACK ]" << endl;
            break;
        case LBRACE:
            outputFile << "LBRACE {" << endl;
            break;
        case RBRACE:
            outputFile << "RBRACE }" << endl;
            break;
        default:
           break;
   }
   return 0;
}

int output2tm(){
    printf("symbol = %d\n", symbol);
}
int neoLexicalAnalysis(bool verify) {
    while(tokenAnalysis() != -1) {
        if (symbol == ANNOTATION) {
            continue;
        }
 
        CompSymbol compSymbol;
        compSymbol.symbol = symbol;
        compSymbol.stringContent = token;
        neotoken = token;
        if(verify){
            output2file();
        }
        symbolList.push_back(compSymbol);
        symbolListI ++;
    }
    symbolListC = symbolListI;
    symbolListI = 0;
    return 0;
}

int getsyms(bool printToFile) {
    if (symbolListI >= symbolListC) {
        symbol = -1;
        neotoken = "";
        return 0; // No more symbols
    }
    symbol = symbolList[symbolListI].symbol;
    neotoken = symbolList[symbolListI].stringContent;
    #ifdef DEBUG_getsyms
        printf("getsysm symbol = %d \n", symbol);
    #endif 
    if (printToFile) {
        output2file();
    }
    symbolListI += 1;
    return 1; // Success
}
int getsysmcurr() {
    if (symbolListI == symbolListC) {
        return -1; // No more symbols
    }
    return symbolList[symbolListI].symbol;
}
int getsysmnext(int n) {
    if (symbolListI + n >= symbolListC) {
        return 0; // No more symbols
    }
    return symbolList[symbolListI+n].symbol;
}